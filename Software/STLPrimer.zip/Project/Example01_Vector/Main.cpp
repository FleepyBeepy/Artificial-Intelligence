// Code by Cromwell D. Enage
#include <iostream>

//[vector_example_program
/*`
[heading Example Program]
Here is the procedural interface for the
[@http://www.sgi.com/tech/stl/Vector.html STL `vector`] example program.
*/
#include <vector>

typedef std::vector<char const*> Names;

void way1();
void way2();
void print1(Names const& names);
void print2(Names const& names);
void modify1(Names& names);
void modify2(Names& names);
/*`
There are two basic ways of looking at a `vector`.  The usual way is to treat
it as a runtime-resizable array, or what is known in the STL as a
[@http://www.sgi.com/tech/stl/RandomAccessContainer.html *random-access*]
[@http://www.sgi.com/tech/stl/Sequence.html *sequence*].  All functions with a
suffix of 1 do this.  The more generic (code-reusable) way is to treat it as a
[@http://www.sgi.com/tech/stl/BackInsertionSequence.html *back-insertion
sequence*]--where you can add and remove elements to and from the back--and
as a [@http://www.sgi.com/tech/stl/Container.html *container*] whose elements
you can access via [@http://www.sgi.com/tech/stl/Iterators.html *iterators*];
all functions with a suffix of 2 do this.

[heading General Usage]
The program initializes a `vector` to hold six names, searches for a name to
remove, inserts another name at another location, and finally removes a name
from the end.  After each major modification, the contents are sent to
standard output.  If you were to treat the `vector` as a runtime-resizable
array, you would write the routine this way:
*/
void way1()
{
    Names names(6);  // fill constructor

    names[0] = "alpha";
    names[1] = "bravo";
    names[2] = "charlie";
    names[3] = "foxtrot";
    names[4] = "echo";
    names[5] = "golf";
    print1(names);

    modify1(names);
    print1(names);

    names.resize(5);
    print1(names);
}
/*`
[heading Traversal Using Indices]
When traversing a `vector`, use the `size` method to obtain the number of
elements it currently holds.  Note that its return type is `std::size_t`; even
though Microsoft Visual Studio's Intellisense database will inform you that
it's a type definition for `unsigned int`, the compiler will emit a warning
with regard to possible loss of data if you explicitly use `unsigned int` or
any other type.  It's up to you if you prefer to `static_cast` the result to
your favorite index type in order to eliminate the warning.
*/
void print1(Names const& names)
{
    for (std::size_t i = 0; i < names.size(); ++i)
    {
        std::cout << ' ' << names[i];
    }

    std::cout << std::endl;
}
/*`
[heading Alternate Usage]
Before we go into how elements are added or removed from an arbitrary
location in the `vector`, we should start looking at the alternative way of
writing the program.  During initialization, as well as when removing from the
end, we could treat the `vector` as a back-insertion sequence.  All
[@http://www.sgi.com/tech/stl/Sequence.html sequences] can be initialized via
the [@http://www.sgi.com/tech/stl/DefaultConstructible.html default
constructor] as long as the element type is also default-constructible, as is
the case with primitive types such as `char const*`.  Elements can then be
pushed to or popped from the back of the `vector`, just as you can do with a
[@http://www.sgi.com/tech/stl/stack.html `stack`].
*/
void way2()
{
    Names names;  // default constructor

    names.push_back("alpha");
    names.push_back("bravo");
    names.push_back("charlie");
    names.push_back("foxtrot");
    names.push_back("echo");
    names.push_back("golf");

    print2(names);
    modify2(names);
    print2(names);

    names.pop_back();
    print2(names);
}
/*`
Note that repeated use of the `push_back` method may result in excessive
reallocation of the underlying raw array.  For this reason, you should use the
[link stl_primer.vector_example.general_usage first way of initialization] as
much as you can.  Otherwise, consider using the [link stl_primer.deque_example
STL `deque`] instead.

[heading Traversal Using Iterators]
Next, the alternative way of traversing a `vector` is to use iterators.  The
iterator types are nested in the container type.  (Had the `print2` function
been templated over the container type, you would have had to precede the
iterator type definition with the `typename` keyword, i.e.
`typename Names::const_iterator`.)
*/
void print2(Names const& names)
{
    // You can also use Names::iterator, which will be implicitly converted to
    // Names::const_iterator.
    for (Names::const_iterator itr = names.begin(); itr != names.end(); ++itr)
    {
        std::cout << ' ' << *itr;
    }

    std::cout << std::endl;
}
/*`
You can see that syntax is more declarative: start from the beginning and
proceed until you've gone past-the-end.  Dereference an iterator just as you
would a pointer in order to access the corresponding element.

[heading Structural Modification]
Getting back to the program, our goal now is to remove all entries named
"echo", then insert an element named "dog" into position three so that it
becomes the fourth element in the vector.  There are still two ways to
perform this routine, but now both ways involve the use of iterators.
*/
void modify1(Names& names)
{
    for (std::size_t i = 0; i < names.size(); ++i)
    {
        if (names[i] == "echo")
        {
            names.erase(names.begin() + i);
            --i;  // Don't skip the next element during iteration.
        }
    }

    names.insert(names.begin() + 3, "dog");
}
/*`
The expression, `names.begin() + i`, returns an iterator that points to the
location where you want to modify the `vector`, just like pointer arithmetic
(except that you can only add to `begin()`, but `i` can be any valid integer
expression).  Furthermore, the `vector` will preserve the sequential order of
its elements after an insertion/removal.

[heading Alternative Structural Modification]
If you use iterators for traversal, then finding and removing "echo" becomes
more straightforward, since you do not need to perform the arithmetic;
however, erasing an element invalidates all iterators referring to it, and
you cannot increment an iterator after it has been invalidated.  It turns out
that the `erase` method returns the next valid iterator if one exists; here's
how you would use it in this case:
*/
void modify2(Names& names)
{
    Names::iterator itr = names.begin();

    while (itr != names.end())
    {
        if (*itr == "echo")
        {
            itr = names.erase(itr);
        }
        else
        {
            ++itr;
        }
    }

    // Insertion remains the same way.
    names.insert(names.begin() + 3, "dog");
}
//]

int main()
{
    way1();
    way2();
    return 0;
}

