// Code by Cromwell D. Enage
#include <iostream>

//[deque_example_program
/*`
[heading Example Program]
Here is the procedural interface for the
[@http://www.sgi.com/tech/stl/Deque.html STL `deque`] example program.
*/
#include <deque>

typedef std::deque<char const*> Names;

void way1();
void way2();
void print1(Names const& names);
void print2(Names const& names);
void modify1(Names& names);
void modify2(Names& names);
/*`
The `deque` combines the random-access abilities of the [link
stl_primer.vector_example `vector`] with the double-ended access/modification
abilities of the [link stl_primer.list_example `list`].  It is the default
underlying [@http://www.sgi.com/tech/stl/Sequence.html sequence] of the
[@http://www.sgi.com/tech/stl/stack.html `stack`] and
[@http://www.sgi.com/tech/stl/queue.html `queue`] container adaptors, because
it avoids potential memory reallocations that occur when a `vector` is used,
while using less memory per element than a `list`.  The trade-off is that the
random access of an element in a `deque` takes slightly longer than that of an
element in a `vector`.

[heading General Usage]
The program initializes a `deque` to hold six names, searches for a name to
remove, inserts another name at another location, and finally removes a name
from the beginning.  After each major modification, the contents are sent to
standard output.  You could use the `deque`
[link stl_primer.vector_example.general_usage almost the same way you used the
`vector`]:
*/
void way1()
{
    Names names(6);  // fill constructor

    names[0] = "alpha";
    names[1] = "bravo";
    names[2] = "charlie";
    names[3] = "foxtrot";
    names[4] = "echo";
    names[5] = "golf";
    print1(names);

    modify1(names);
    print1(names);

    names.pop_front();
    print1(names);
}
/*`
If `names` were a vector, you would have to use the less efficient
`names.erase(names.begin())` instead of `names.pop_front()`.  For a deque, on
the other hand, both expressions are equivalent performance-wise.

[heading Alternative Usage]
You could also use the `deque` [link stl_primer.list_example.general_usage the
same way you used the `list`]:
*/
void way2()
{
    Names names;  // default constructor

    names.push_back("foxtrot");
    names.push_back("echo");
    names.push_back("golf");
    names.push_front("charlie");
    names.push_front("bravo");
    names.push_front("alpha");

    print2(names);
    modify2(names);
    print2(names);

    names.pop_front();
    print2(names);
}
/*`
The rest of this program is the same as [link stl_primer.vector_example that
of the `vector` example program].
*/
//]

void print1(Names const& names)
{
    for (std::size_t i = 0; i < names.size(); ++i)
    {
        std::cout << ' ' << names[i];
    }

    std::cout << std::endl;
}

void print2(Names const& names)
{
    // You can also use Names::iterator, which will be implicitly converted to
    // Names::const_iterator.
    for (Names::const_iterator itr = names.begin(); itr != names.end(); ++itr)
    {
        std::cout << ' ' << *itr;
    }

    std::cout << std::endl;
}

void modify1(Names& names)
{
    for (std::size_t i = 0; i < names.size(); ++i)
    {
        if (names[i] == "echo")
        {
            names.erase(names.begin() + i);
            --i;
        }
    }

    names.insert(names.begin() + 3, "dog");
}

void modify2(Names& names)
{
    Names::iterator itr = names.begin();

    while (itr != names.end())
    {
        if (*itr == "echo")
        {
            itr = names.erase(itr);
        }
        else
        {
            ++itr;
        }
    }

    // Insertion remains the same way.
    names.insert(names.begin() + 3, "dog");
}

int main()
{
    way1();
    way2();
    return 0;
}

