// Code by Cromwell D. Enage
#include <iostream>

//[list_example_program
/*`
[heading Example Program]
Here is the procedural interface for the
[@http://www.sgi.com/tech/stl/List.html STL `list`] example program.
*/
#include <list>

typedef std::list<char const*> Names;

void print(Names const& names);
void modify(Names& names);
/*`
Like the [link stl_primer.vector_example STL `vector`], the `list` is a
[@http://www.sgi.com/tech/stl/Container.html container] whose elements you can
access via [@http://www.sgi.com/tech/stl/Iterators.html iterators].  You can
also add and remove elements to and from the back of a `list`, because it is a
[@http://www.sgi.com/tech/stl/BackInsertionSequence.html back-insertion
sequence].  Unlike the `vector`, you can even add and remove elements to and
from the /front/ of a `list`, because it is also a
[@http://www.sgi.com/tech/stl/FrontInsertionSequence.html
*front-insertion sequence*].  The trade-off is that the `list` doesn't provide
[@http://www.sgi.com/tech/stl/RandomAccessContainer.html random access] to its
elements.

[heading General Usage]
The program initializes a `list` to hold six names, searches for a name to
remove, and removes another name from the beginning.  After each major
modification, the contents are sent to standard output.
*/
int main()
{
    Names names;

    names.push_back("foxtrot");
    names.push_back("echo");
    names.push_back("golf");
    names.push_front("charlie");
    names.push_front("bravo");
    names.push_front("alpha");
    print(names);

    modify(names);
    print(names);

    names.pop_front();
    print(names);

    return 0;
}
/*`
[heading Traversal Using Iterators]
The [link stl_primer.vector_example.traversal_using_iterators generic way to
traverse a `vector`] is also the only way to efficiently traverse a `list`.
*/
void print(Names const& names)
{
    for (Names::const_iterator itr = names.begin(); itr != names.end(); ++itr)
    {
        std::cout << ' ' << *itr;
    }

    std::cout << std::endl;
}
/*`
[heading Structural Modification]
The same goes for
[link stl_primer.vector_example.alternative_structural_modification finding
and removing an element] from the `list`.
*/
void modify(Names& names)
{
    Names::iterator itr = names.begin();

    while (itr != names.end())
    {
        if (*itr == "echo")
        {
            itr = names.erase(itr);
        }
        else
        {
            ++itr;
        }
    }
}
//]

