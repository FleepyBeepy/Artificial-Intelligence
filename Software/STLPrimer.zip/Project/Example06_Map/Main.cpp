// Code by Cromwell D. Enage
#include <iostream>

//[map_example_program
/*`
[heading Heap-Allocated Elements]
One restriction you'll run into with
[@http://www.sgi.com/tech/stl/Container.html STL containers] is that all
user-defined element types have to implement the copy constructor and the
assignment operator.  (This requirement is defined by the
[@http://www.sgi.com/tech/stl/Assignable.html *Assignable* concept], which all
container element types must model; primitive types such as `int` or raw
pointers have built-in mechanisms to work around this restriction.)  Here's a
user-defined type that /doesn't/ model the *Assignable* concept.
*/
struct PhoneNumber
{
    unsigned int const area_code;
    unsigned int const seven_digits;

    PhoneNumber(unsigned int code, unsigned int last_four_digits)
        : area_code(code), seven_digits(5550000 + (last_four_digits % 10000))
    {
    }
};
/*`
Normally, in the absence of an explicit copy constructor or assignment
operator, the compiler generates a definition for you.  However, the presence
of the `const` member variables inhibits this ability.  You can either provide
the definitions yourself, or you can define your STL container to hold
pointers rather than the objects themselves.  In this tutorial, we will take
the latter approach, which means that our `PhoneNumber` objects will be
allocated on the heap rather than on the stack.

[heading Function Object Redux]
The [@http://www.sgi.com/tech/stl/Map.html STL `map`], like the
[link stl_primer.set_example STL `set`], requires a comparator that imposes a
[@http://www.sgi.com/tech/stl/StrictWeakOrdering.html strict weak ordering] on
its keys.
*/
#include <cstring>

bool compareCStyleStrings(char const* lhs, char const* rhs)
{
    return strcmp(lhs, rhs) < 0;
}
/*`
[heading Example Program]
Here is the procedural interface for the `map` example program.
*/
#include <map>

typedef std::map<char const*,PhoneNumber*,bool(*)(char const*,char const*)>
        PhoneBook;

void print(PhoneBook const& phonebook);
void search(PhoneBook const& phonebook, char const* name);
void remove(PhoneBook& phonebook, char const* name);
void reset(PhoneBook& phonebook);

// Routines with issues worth mentioning.
void no_no();
void search2(PhoneBook& phonebook, char const* name);
/*`
The `map` is different from the [link stl_primer.vector_example other]
[link stl_primer.list_example containers] [link stl_primer.deque_example
you've] [link stl_primer.set_example encountered] so far.  Its purpose is to
associate keys with values, so its element type is actually a
[link stl_primer.pair_example `pair`]--in this case,
`std::pair<char const*,PhoneNumber*>`.  The comparator is used to order the
elements by key.

[heading General Usage]
There are two ways to insert elements into a `map`.  The generic `insert`
method explicitly takes in a key-value `pair`.  The more convenient bracket
operator, used by the [link stl_primer.vector_example STL `vector`] to provide
random access, takes in a `key` element instead of an index.
*/
int main()
{
    PhoneBook phonebook(compareCStyleStrings);

    phonebook.insert(
        PhoneBook::value_type("Native Floridian", new PhoneNumber(407, 4321))
    );
    phonebook["New Yorker"] = new PhoneNumber(212, 6789);
    phonebook["Haxor, Gr8"] = new PhoneNumber(321, 1337);
    print(phonebook);

    search(phonebook, "Native Floridian");
    remove(phonebook, "Native Floridian");
    print(phonebook);

    search(phonebook, "Native Floridian");
    remove(phonebook, "Native Floridian");

#ifdef TEST_SEARCH_2
    search2(phonebook, "Native Floridian");
    print(phonebook);
#endif

    reset(phonebook);
    print(phonebook);

//    no_no();

    return 0;
}
/*`
[heading Traversal Using Iterators]
Remember that the `map` element type is a `pair`, so its iterators will refer
to `pair` objects.  Use the `first` member variable to access the key element
and the `second` member variable to access the corresponding value element.
*/
void print(PhoneBook const& phonebook)
{
    if (phonebook.empty())
    {
        std::cout << "The phone book is empty." << std::endl;
        return;
    }

    std::cout << "Phone book:" << std::endl;

    for (
        PhoneBook::const_iterator itr = phonebook.begin();
        itr != phonebook.end();
        ++itr
    )
    {
        std::cout << '\t' << itr->first << " => (" << itr->second->area_code;
        std::cout << ") " << itr->second->seven_digits << std::endl;
    }
}
/*`
[tip
All STL containers implement the `empty` method.  Use it to check if there are
no elements remaining.
]

[warning
During the course of your programming career, you'll most likely encounter
type definitions such as `std::map<int,Node*>` whose `key` is an integer type,
and you'll be tempted to use the bracket operator as if the container were a
`vector`, like so:
*/
struct Node
{
    int x_coordinate;
    int y_coordinate;

    Node(int x, int y) : x_coordinate(x), y_coordinate(y)
    {
    }
};

void no_no()
{
    typedef std::map<int,Node*> NodeMap;

    NodeMap nodemap;

    nodemap[42] = new Node(3, 1);
    std::cout << std::endl << "This is how NOT to use a map:" << std::endl;

    for (int index = 0; index < static_cast<int>(nodemap.size()); ++index)
    {
        if (nodemap[index])
        {
            std::cout << "\tx = " << nodemap[index]->x_coordinate;
            std::cout << ", y = " << nodemap[index]->y_coordinate << std::endl;
        }
        else
        {
            std::cout << '\t' << index << " not in node map." << std::endl;
        }
    }

    delete nodemap[42];
}
/*`
Can you guess how many iterations this loop will make?  Uncomment the call to
this function from within the main program, and you will see that using the
bracket operator this way is a really bad idea.

The reason: the bracket operator will insert a new entry /every/ time it is
passed in a key that is not already in the `map`.  (A function cannot know
whether it is being invoked as an accessor or as a modifier unless it is
`const`-qualified, which the bracket operator is not.)  Of course, this
increments the size of the `map`, which means that the loop will run more
times than you intended for it to.  Any application that iterates this way
through a `map` with large keys will experience a prohibitive degradation
in runtime performance.
]

[heading Search]
The main use-case of a `map` is the ability to obtain the corresponding value
element when given a key element.  Otherwise, the `find` method works
[link stl_primer.set_example.search the same way that the corresponding method
does for the `set`].
*/
void search(PhoneBook const& phonebook, char const* name)
{
    PhoneBook::const_iterator itr = phonebook.find(name);

    if (itr == phonebook.end())
    {
        std::cout << name << " is not in the phone book." << std::endl;
    }
    else
    {
        std::cout << "The phone number of " << itr->first << " is (";
        std::cout << itr->second->area_code << ") ";
        std::cout << itr->second->seven_digits << '.' << std::endl;
    }
}
/*`
[caution
Some people will tell you that the bracket operator is faster than the `find`
method when searching for a particular key, especially since Microsoft's STL
implementation adds extra iterator-debugging code whenever it is compiled in
debug mode.
*/
void search2(PhoneBook& phonebook, char const* name)
{
    if (phonebook[name])
    {
        std::cout << "The phone number of " << name << " is (";
        std::cout << phonebook[name]->area_code << ") ";
        std::cout << phonebook[name]->seven_digits << '.' << std::endl;
    }
    else
    {
        std::cout << name << " is not in the phone book." << std::endl;
    }
}
/*`
First, notice that the `phonebook` object is not `const`-qualified here as it
was in the other `search` function, because the bracket operator is not
`const`-qualified.  This means that you could accidentally change the value
to which a key is assigned, and the compiler won't be able to stop you from
doing so.  In general, it is better to catch errors at compile-time than at
runtime, because it saves you development time in the long run.

Second, remember that the bracket operator will insert a new entry /every/
time it is passed in a key that is not already in the `map`; this will affect
the way you iterate through one later on.  Define the `TEST_SEARCH_2`
preprocessor token: your program will crash because the `print` function is
trying to access the data members of a `NULL` pointer.  You could add an extra
`if` check inside the iteration loop, but is the marginal speed gain offered
by the bracket operator /really/ worth the trouble it can cause?

Moral: know what you're doing before you optimize.
]

[heading Removing A Heap-Allocated Element]
Removing a key-value pair from a `map` is trickier if elements are allocated
on the heap.  Although you could use the `erase` method overload that takes in
a key element, calling just that method would leak the memory used to allocate
the `PhoneNumber` value element.  Instead, use the `find` method together with
the generic `erase` method overload that takes in an iterator so that you can
`delete` the value element beforehand.
*/
void remove(PhoneBook& phonebook, char const* name)
{
    PhoneBook::iterator itr = phonebook.find(name);

    if (itr != phonebook.end())
    {
        std::cout << "Removing " << itr->first << "..." << std::endl;
        delete itr->second;
        phonebook.erase(itr);
    }
}
/*`
[important
The rules regarding the removal of heap-allocated elements apply to all STL
containers.
]

[heading Removing All Elements]
Removing all elements from a `map` is more straightforward: traverse the
key-value pairs and `delete` the heap-allocated objects, then clear the `map`
itself.
*/
void reset(PhoneBook& phonebook)
{
    for (
        PhoneBook::iterator itr = phonebook.begin();
        itr != phonebook.end();
        ++itr
    )
    {
        delete itr->second;
    }

    phonebook.clear();
}
/*`
[tip
All [@http://www.sgi.com/tech/stl/Sequence.html STL sequences] implement the
`clear` method.
]
*/
//]

