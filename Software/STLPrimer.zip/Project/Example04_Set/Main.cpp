// Code by Cromwell D. Enage
#define _CRT_SECURE_NO_DEPRECATE  // Fixed in MSVC 9.0 (Visual Studio 2008)
#include <iostream>

//[set_example_program
/*`
[heading Function Objects]
The more advanced [@http://www.sgi.com/tech/stl/Container.html STL containers]
impose stricter requirements on their element types.  In the case of the
[@http://www.sgi.com/tech/stl/set.html STL `set`], objects of its element type
must have some kind of ordering imposed on them.  The simplest way to fulfill
this requirement would be to overload the less-than operator for that type,
but in many cases the implementation may not work the way you want it to work
for the primitive type you're using, or maybe you're not able to overload the
less-than operator for a type defined by someone else.

The most flexible way to customize the behavior of an STL container is by
defining a [link stl_primer.functors_example *function object*] that the
container can use.  Technically speaking, a function object can be any one of
the following:

* an ordinary function.
* a function pointer.
* an instance of a class that defines the function call operator as one of its
members.

[note
Throughout this primer, we will use the term [link stl_primer.functors_example
*functor*] when dealing with the last definition, so that we can distinguish
between this case and other two.
]

For example, you want a set that sorts C-style strings in lexicographical
order, but the STL `set` sees no difference between C-style strings and
regular pointers, so the less-than operator would sort by memory address
instead.  To impose the desired ordering in this case, you could just create
an ordinary function like so:
*/
#include <cstring>

bool compareCStyleStrings(char const* lhs, char const* rhs)
{
    return strcmp(lhs, rhs) < 0;
}
/*`
A function object that imposes a
[@http://www.sgi.com/tech/stl/StrictWeakOrdering.html strict weak ordering] on
its arguments is called a *comparator*.  The STL `set` expects your comparator
to fulfill the following requirements:

* The function object must be able to take in two arguments.
* The `set` element type must be convertible to either argument type.
* The return type must be convertible to `bool`.

[heading Example Program]
Now, here is the procedural interface for the `set` example program.
*/
#include <set>

typedef std::set<char const*,bool(*)(char const*,char const*)> Names;

void print(Names const& names);
void search(Names const& names, char const* name);
void search2(Names const& names, char const* name);
void remove(Names& names, char const* name);

// Routines with issues worth mentioning.
void oops();
void much_worse();
void somewhat_better();
/*`
[heading General Usage]
The program initializes a `set` to hold some names, searches for a name to
remove, and removes another name from the beginning.  After each major
modification, the contents are sent to standard output.  Because a `set` keeps
its elements ordered at all times, there is really only one way to add one
element at a time.
*/
int main()
{
    Names names(compareCStyleStrings);

    names.insert("echo");
    names.insert("bravo");
    names.insert("alpha");
    names.insert("charlie");
    names.insert("foxtrot");
    names.insert("echo");  // No effect on the std::set
    names.insert("golf");
    print(names);

    search(names, "echo");
    remove(names, "echo");
    print(names);
    search(names, "echo");
    remove(names, "echo");

    names.erase(names.begin());
    print(names);

    std::cout << "Oops:" << std::endl; oops();
    std::cout << "Much worse:" << std::endl; much_worse();
    std::cout << "Better:" << std::endl; somewhat_better();

    return 0;
}
/*`
[heading Traversal Using Iterators]
If you can [link stl_primer.list_example.traversal_using_iterators traverse a
`list`], you can traverse a `set`.
*/
void print(Names const& names)
{
    for (Names::const_iterator itr = names.begin(); itr != names.end(); ++itr)
    {
        std::cout << ' ' << *itr;
    }

    std::cout << std::endl;
}
/*`
[heading Search]
Of course, the real reason you would use a `set` over a `vector`, a `deque`,
or a `list` is the ability to efficiently check for the presence of a certain
element if the total number of elements is large.  However, like most things
STL, the `find` method returns an iterator rather than a simple boolean value.
*/
void search(Names const& names, char const* name)
{
    if (names.find(name) == names.end())
    {
        std::cout << name << " is not in the set." << std::endl;
    }
    else
    {
        std::cout << name << " is in the set." << std::endl;
    }
}
/*`
If you change the `Names` type definition from `set` to
[@http://www.sgi.com/tech/stl/multiset.html `multiset`] and then call
`search2` instead of `search` in the main program, you could see why: the
statement within the `do`-`while` loop would execute as many times as there
were duplicates of the specified name.
*/
void search2(Names const& names, char const* name)
{
    Names::const_iterator itr = names.find(name);

    if (itr == names.end())
    {
        std::cout << name << " is not in the container." << std::endl;
    }
    else
    {
        do
        {
            std::cout << *itr << " is in the container." << std::endl;
        }
        while (++itr != names.end());
    }
}
/*`
[heading Removing An Element]
Remember the
[link stl_primer.vector_example.alternative_structural_modification `erase`
method] of the `vector` class template?  Both the `set` and `multiset` class
templates provide a more efficient overload that takes in an element and
returns the actual number of elements removed.
*/
void remove(Names& names, char const* name)
{
    std::cout << names.erase("echo") << " element(s) erased." << std::endl;
}
/*`
[warning
The fact that the less-than operator orders raw pointers by memory address
can lead to subtle bugs involving non-`const` character arrays:
*/
void oops()
{
    Names names(compareCStyleStrings);
    char buffer[10];

    strcpy(buffer, "echo");
    names.insert(buffer);
    strcpy(buffer, "bravo");
    names.insert(buffer);
    strcpy(buffer, "alpha");
    names.insert(buffer);
    strcpy(buffer, "charlie");
    names.insert(buffer);
    strcpy(buffer, "foxtrot");
    names.insert(buffer);
    strcpy(buffer, "echo");
    names.insert(buffer);
    strcpy(buffer, "golf");
    names.insert(buffer);
    print(names);

    search(names, "echo");
    remove(names, "echo");
    print(names);
    search(names, "echo");
    remove(names, "echo");

    names.erase(names.begin());
    print(names);
}
/*`
The code above repeatedly inserts a pointer to the same memory address, so the
number of names never exceeds one.  Here's a naive attempt to refactor the
insertion code into a separate function:
*/
void try_to_add(Names& names, char const* name)
{
    char buffer[10];
    strcpy(buffer, name);
    names.insert(buffer);
}

void much_worse()
{
    Names names(compareCStyleStrings);

    try_to_add(names, "echo");
    try_to_add(names, "bravo");
    try_to_add(names, "alpha");
    try_to_add(names, "charlie");
    try_to_add(names, "foxtrot");
    try_to_add(names, "echo");
    try_to_add(names, "golf");
    print(names);

    search(names, "echo");
    remove(names, "echo");
    print(names);
    search(names, "echo");
    remove(names, "echo");

    names.erase(names.begin());
    print(names);
}
/*`
Array memory allocated on the stack can turn bad when variables like `buffer`
fall out of scope, which happens at the end of each `try_to_add` function call
in this case.  In order to keep the memory alive, you must allocate it on the
heap:
*/
void add(Names& names, char const* name)
{
    char* buffer = new char[strlen(name) + 1];
    strcpy(buffer, name);
    names.insert(buffer);
}

void somewhat_better()
{
    Names names(compareCStyleStrings);

    add(names, "echo");
    add(names, "bravo");
    add(names, "alpha");
    add(names, "charlie");
    add(names, "foxtrot");
    add(names, "echo");
    add(names, "golf");
    print(names);

    search(names, "echo");
    remove(names, "echo");
    print(names);
    search(names, "echo");
    remove(names, "echo");

    names.erase(names.begin());
    print(names);

    // Clean up all heap-allocated memory.
    for (Names::iterator itr = names.begin(); itr != names.end(); ++itr)
    {
        delete[] *itr;
    }

    names.clear();
}
/*`
The C++ standard includes [link stl_primer.string_example the `string` data
type] so that you can avoid these issues more easily.
]
*/
//]

