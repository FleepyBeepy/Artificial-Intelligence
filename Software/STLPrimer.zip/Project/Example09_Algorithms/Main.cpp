// Code by Cromwell D. Enage
#define _CRT_SECURE_NO_DEPRECATE  // Fixed in MSVC 9.0 (Visual Studio 2008)

// Heed our warning about std::copy et al, not Microsoft's warning.
#pragma warning(disable: 4996)

#include <cassert>
#include <cmath>
#include <cstring>
#include <iostream>
#include <vector>
#include <list>
#include <deque>
#include <string>

//[algorithms_example_program
/*`
[heading Algorithmic Reuse]
Sooner or later, you may grow tired of writing the same `for` loop that always
iterates from the beginning to the end of a container, searching for and
removing or replacing elements that no longer belong there, and so on.  Code
duplication then becomes an issue at the /algorithmic level/ rather than at
the /data structure level/, where it is
[link stl_primer.vector_example addressed] [link stl_primer.list_example by]
[link stl_primer.deque_example the] [link stl_primer.set_example STL]
[link stl_primer.map_example containers].  Instead, the
[@http://www.sgi.com/tech/stl/ STL] provides a family of reusable function
templates to help you refactor the code that is shared across the algorithms
you write.  The idea is that you would only write your problem-specific code
inside one or more [link stl_primer.functors_example function objects] that
could then be used by the STL routines.  Not surprisingly, the authors of the
STL also call these routines *algorithms*, so they've defined them in this
standard C++ header file:
*/
#include <algorithm>
/*`
[heading `for_each`]
The purpose of this STL algorithm should be obvious.  Write a single-argument
function or [link stl_primer.functors_example functor] that takes in a
container element and performs an action on that element.  The
[@http://www.sgi.com/tech/stl/for_each.html `for_each` function template] will
execute your function over all elements within the range specified by the
iterators you pass in.  (All STL algorithms take in at least one *iterator
range*, which is a pair of [@http://www.sgi.com/tech/stl/InputIterator.html
input iterators] specifying the start and past-the-end positions of the
elements to work on.)
*/
class Sprite
{
    static unsigned int constructed_count;
    unsigned int id;

 public:
    Sprite() : id(++constructed_count)
    {
    }

    unsigned int getID() const
    {
        return id;
    }
};

unsigned int Sprite::constructed_count = 0;

void displaySprite(Sprite const& sprite)
{
    std::cout << "Sprite ID = " << sprite.getID() << std::endl;
}

void outputAllSpriteIDs(std::vector<Sprite> const& sprites)
{
    std::for_each(sprites.begin(), sprites.end(), displaySprite);
}
/*`
Did you know that raw pointers can also be STL iterators?
*/
void outputAllSpriteIDsAgain(Sprite* sprites, std::size_t count)
{
    std::for_each(sprites, sprites + count, displaySprite);
}
/*`
[warning
You /must/ specify the desired number of iterations for C-style arrays.  This
code does not work:
*/
void outputAllSpriteIDs_orNot(Sprite* sprites)
{
    std::for_each(
        sprites
      , sprites + sizeof(sprites) / sizeof(Sprite)
      , displaySprite
    );
}
/*`
The `sizeof(sprites)` will just return the size of the pointer itself,
e.g. the return value will be `4` on 32-bit systems.
]

[heading `find`]
Recall that the [link stl_primer.set_example `set`] and
[link stl_primer.set_example `multiset`] containers have efficient
[link stl_primer.set_example.search `find` methods] for determining whether or
not they contain the elements being passed in.  With the other STL containers,
you can use the generic [@http://www.sgi.com/tech/stl/find.html `find`
algorithm] for the same purpose: it will return an iterator pointing to the
element found in the specified range, or it will return the second iterator
passed in if no such element exists.
*/
void lookupName(std::list<char const*> const& names, char const* name)
{
    if (std::find(names.begin(), names.end(), name) == names.end())
    {
        std::cout << name << " is not in the list." << std::endl;
    }
    else
    {
        std::cout << name << " is in the list." << std::endl;
    }
}
/*`
If your element type is user-defined (not a /pointer/ to a user-defined type),
[@http://www.sgi.com/tech/stl/EqualityComparable.html the equality and
inequality comparison operators must also be defined for it]:
*/
struct Card
{
    char rank;
    enum Suit {HEART = 3, DIAMOND, CLUB, SPADE} suit;
};

bool operator==(Card const& lhs, Card const& rhs)
{
    return (lhs.rank == rhs.rank) && (lhs.suit == rhs.suit);
}

bool operator!=(Card const& lhs, Card const& rhs)
{
    return (lhs.rank != rhs.rank) || (lhs.suit != rhs.suit);
}

void displayCard(Card const& card)
{
    std::cout << ' ' << card.rank << static_cast<char>(card.suit);
}

void lookupCard(std::deque<Card> const& deck, Card const& card)
{
    displayCard(card);

    if (std::find(deck.begin(), deck.end(), card) == deck.end())
    {
        std::cout << " is not in the deck." << std::endl;
    }
    else
    {
        std::cout << " is in the deck." << std::endl;
    }
}
/*`
[heading `find_if`]
The `find` algorithm will fail you if any of the following scenarios apply:

* You do not want to find an element using equality semantics.
* You cannot define either comparison operator.
* The ones provided do not behave the way you want them to.

In these cases you must use the more general
[@http://www.sgi.com/tech/stl/find_if.html `find_if` algorithm].  Define a
function object that returns `true` if and only if the element being passed in
is the one you're looking for, then let `find_if` do its job.
*/
struct Point
{
    double x;
    double y;
};

class InCloseProximity
{
    Point location;
    double radius_squared;

 public:
    InCloseProximity(Point const& p, double r)
        : location(p), radius_squared(r * r)
    {
    }

    bool operator()(Point const& p) const
    {
        double dx = location.x - p.x;
        double dy = location.y - p.y;

        // Since we're only comparing relative distances,
        // we don't need to perform a square root operation here.
        return dx * dx + dy * dy < radius_squared;
    }
};

void checkCollisionOnce(std::list<Point> const& points, Point const& p)
{
    std::list<Point>::const_iterator itr = std::find_if(
        points.begin()
      , points.end()
      , InCloseProximity(p, 0.5)
    );

    if (itr == points.end())
    {
        std::cout << '[' << p.x << ',' << p.y << "] has not triggered.";
    }
    else
    {
        std::cout << '[' << itr->x << ',' << itr->y;
        std::cout << "] is close enough to [" << p.x << ',' << p.y << "].";
    }

    std::cout << std::endl;
}
/*`
Now, both `find` and `find_if` will return the /first/ iterator for whose
element the equality comparison operator or function object will return
`true`.  To find /all/ the elements you want, you still need a manual loop:
*/
void checkCollision(std::list<Point> const& points, Point const& p)
{
    InCloseProximity in_close_proximity(p, 0.5);
    std::list<Point>::const_iterator itr_end = points.end();

    for (
        std::list<Point>::const_iterator itr = points.begin();
        (itr = std::find_if(itr, itr_end, in_close_proximity)) != itr_end;
        ++itr
    )
    {
        std::cout << '[' << itr->x << ',' << itr->y << "] is close enough.";
        std::cout << std::endl;
    }
}
/*`
[note
There have been discussions about including a `for_each_if` algorithm in the
C++ Standard Library.  See this
[@http://www.crystalclearsoftware.com/cgi-bin/boost_wiki/wiki.pl?STLAlgorithmExtensions/ForEachIf
Boost Wiki page] for starters.
]

[heading `search`]
While the `find` and `find_if` algorithms look for a single element, the
[@http://www.sgi.com/tech/stl/search.html STL `search` algorithm] looks for
elements that are next to each other in a sequence.  The canonical use case is
to test for the presence of a word in a sentence by treating both of them as
sequences of letters:
*/
void wordFind(char const* sentence, char const* word)
{
    char const* end_of_sentence = sentence + strlen(sentence);

    if (
        std::search(sentence, end_of_sentence, word, word + strlen(word))
     == end_of_sentence
    )
    {
        std::cout << '\"' << word << "\" is not in \"" << sentence;
    }
    else
    {
        std::cout << '\"' << word << "\" is in \"" << sentence;
    }

    std::cout << "\"." << std::endl;
}
/*`
The `search` function template is overloaded; instead of using the default
equality semantics to compare two elements, you can also pass in your own
function object, as long as it fulfills the following requirements:

* The function object must be able to take in two arguments:
    # an element in the range to search inside.
    # an element in the range to search for.
* The return value must be usable in a boolean expression.

This example looks for a sequence of points that approximate a desired path:
*/
class AreCloseEnough
{
    double radius_squared;

 public:
    explicit AreCloseEnough(double r) : radius_squared(r * r)
    {
    }

    bool operator()(Point const& lhs, Point const& rhs) const
    {
        double dx = rhs.x - lhs.x;
        double dy = rhs.y - lhs.y;
        return dx * dx + dy * dy < radius_squared;
    }
};

void displayPoint(Point const& p)
{
    std::cout << "[x=" << p.x << ",y=" << p.y << ']';
}

void pathFind(std::list<Point> const& points, Point path[], std::size_t length)
{
    std::list<Point>::const_iterator same_path = std::search(
        points.begin()
      , points.end()
      , path
      , path + length
      , AreCloseEnough(0.5)
    );

    if (same_path == points.end())
    {
        std::cout << "Path not found." << std::endl;
    }
    else
    {
        for (std::size_t index = length; index; --index)
        {
            displayPoint(*same_path);
            ++same_path;
        }

        std::cout << std::endl << "in points approximates" << std::endl;
        std::for_each(path, path + length, displayPoint);
        std::cout << '.' << std::endl;
    }
}
/*`
[heading `equal` and `lexicographical_compare`]
Although "War" is arguably the most boring card game for children over the age
of five, its battle resolution system is simple to implement and can be reused
in more interactive turn-based games.  First, write two comparators: one that
checks for rank equality, and one that determines whether or not the first
card will lose to the second one.
*/
bool checkEqualityForWar(Card const& lhs, Card const& rhs)
{
    return lhs.rank == rhs.rank;
}

bool compareForWar(Card const& lhs, Card const& rhs)
{
    switch (lhs.rank)
    {
        case 'A':
            return false;

        case 'T':
            if (rhs.rank == 'J')
            {
                return true;
            }
            // Fall through.

        case 'J':
            if (rhs.rank == 'Q')
            {
                return true;
            }
            // Fall through.

        case 'Q':
            if (rhs.rank == 'K')
            {
                return true;
            }
            // Fall through.

        case 'K':
            return rhs.rank == 'A';

        default:
            switch (rhs.rank)
            {
                case 'T':
                case 'J':
                case 'Q':
                case 'K':
                case 'A':
                    return true;

                default:
                    return lhs.rank < rhs.rank;
            }
    }
}
/*`
Then, use the [@http://www.sgi.com/tech/stl/equal.html `equal` algorithm]
to determine whether two hands are tied in a standoff, and use the
`lexicographical_compare` to determine whether or not the second hand beats
the first one.  The [@http://www.sgi.com/tech/stl/lexicographical_compare.html
`lexicographical_compare` algorithm] takes in two iterator ranges and performs
sequential tie-breakers on the corresponding elements in each range until the
tie is broken (or until the end of one of the ranges is reached, in which case
the hand represented by the other range wins).  In contrast, `equal` does not
need to take in the end of the second range, since two ranges of different
lengths can never be equivalent.
*/
void playOneRound(std::deque<Card>& deck1, std::deque<Card>& deck2)
{
    std::vector<Card> hand1;
    std::vector<Card> hand2;

    // Read the tip after the end of this routine.
    hand1.reserve(deck1.size());
    hand2.reserve(deck2.size());

    while (!deck1.empty() && !deck2.empty())
    {
        // Ignore discard piles and "I declare war" incantations
        // for this example.
        hand1.push_back(deck1.front());
        deck1.pop_front();
        hand2.push_back(deck2.front());
        deck2.pop_front();

        // Outputs are useful.
        std::cout << "  Hand 1:";
        std::for_each(hand1.begin(), hand1.end(), displayCard);
        std::cout << std::endl << "  Hand 2:";
        std::for_each(hand2.begin(), hand2.end(), displayCard);
        std::cout << std::endl;

        // The order of comparisons is important.
        if (
            std::equal(
                hand1.begin()
              , hand1.end()
              , hand2.begin()
              , checkEqualityForWar
            )
        )
        {
            std::cout << "Tie" << std::endl;
        }
        else if (
            std::lexicographical_compare(
                hand1.begin()
              , hand1.end()
              , hand2.begin()
              , hand2.end()
              , compareForWar
            )
        )
        {
            std::cout << "Hand 2 wins this time." << std::endl;
            hand1.clear();
            hand2.clear();
        }
        else
        {
            std::cout << "Hand 1 wins this time." << std::endl;
            hand1.clear();
            hand2.clear();
        }
    }
}
/*`
[tip
If you're reasonably sure that a resizable array won't exceed a certain size,
use a [link stl_primer.vector_example `vector`] instead of a
[link stl_primer.deque_example `deque`] for better space efficiency, and pass
that size to its `reserve` method to minimize the number of array memory
reallocations.
]

[heading `remove`]
The STL does not provide a single generic function template that actually
erases elements from a container.  This makes sense when you consider that the
STL algorithms were written to accomodate C-style arrays--for which element
erasure is not possible--almost as well as STL containers.  Therefore, the
[@http://www.sgi.com/tech/stl/remove.html `remove`] and
[@http://www.sgi.com/tech/stl/remove_if.html `remove_if`] algorithms behave
somewhat differently from a container's `erase` method: each one modifies the
range of iterators such that those elements that won't be removed are
separated from the ones that will be.  The iterator returned by each algorithm
then points to the first element that should be removed.

The `remove_if` variant imposes the following requirements on its function
object parameter:

* Be able to accept a container element as its only argument.
* Return `true` if the element should be removed from the container.
* Return `false` otherwise.
*/
bool isRoyal(Card const& card)
{
    switch (card.rank)
    {
        case 'K':
        case 'Q':
        case 'J':
            return true;

        default:
            return false;
    }
}

void makeNumericalDeck(Card deck[], std::size_t size)
{
    Card* itr = deck;
    Card* itr_end = deck + size;
    Card* rem_itr = std::remove_if(itr, itr_end, isRoyal);

    std::cout << std::endl << "Must stay in deck:";
    std::for_each(itr, rem_itr, displayCard);
    std::cout << std::endl << std::endl << "Must be removed from deck:";
    std::for_each(rem_itr, itr_end, displayCard);
    std::cout << std::endl;
}
/*`
Each [@http://www.sgi.com/tech/stl/Sequence.html STL sequence] /does/ provide
an overloaded `erase` method that can take in the results of your `remove` or
`remove_if` calls:
*/
void makeNumericalDeck(std::deque<Card>& deck)
{
    std::deque<Card>::iterator itr_end = deck.erase(
        std::remove_if(deck.begin(), deck.end(), isRoyal)
      , deck.end()
    );

    std::cout << std::endl << "Making numerical deck:";
    std::for_each(deck.begin(), deck.end(), displayCard);
    std::cout << std::endl;
}
/*`
Depending on the type of container you use, this `erase` method overload may
be more efficient than the single-argument overload called over all elements
to be removed.

[warning
The result of dereferencing the iterator returned by either `remove` or
`remove_if` depends on the implementation.  For example, if your container is
`{1, 2, 3, 4, 5}` and you want to remove `2` and `3`, do not expect the return
iterator to point to `2`; you are only guaranteed that the container will hold
`{1, 4, 5, #, #}`.

In particular, if your container holds pointers to heap-allocated objects, do
not `delete` the elements you are about to erase.  Instead, `delete` them in
your function object just before returning `true`.
]

[heading `copy`]
Sometimes you need to copy the contents of one container into another.  In
addition to the usual pair of iterators specifying the range of input
elements, the [@http://www.sgi.com/tech/stl/copy.html `copy` algorithm] takes
in an [@http://www.sgi.com/tech/stl/OutputIterator.html *output iterator*]
through which the copies will be stored.
*/
void copyDeck(std::deque<Card> const& deck, Card cards[])
{
    std::cout << std::endl << "Copying deck:";
    std::for_each(
        cards
      , std::copy(deck.begin(), deck.end(), cards)
      , displayCard
    );
    std::cout << std::endl;
}
/*`
[warning
Remember: all STL algorithms were written to accomodate C-style arrays, which
are not resizable; hence, the target container must already hold enough memory
to store the copies.  Furthermore, you must uphold this condition even when
the target container /is/ an STL container.  To work around this restriction,
wrap your STL container inside a
[link stl_primer.adaptors_example.copying_without_presizing
`back_insert_iterator` or `insert_iterator` adaptor].
]

[heading `remove_copy`]
This [@http://www.sgi.com/tech/stl/remove_copy.html STL algorithm] has a
somewhat confusing name.  It does /not/ remove duplicate elements from a
container; instead, it copies only those elements that are not equal to the
specified element.
*/
void
    ostracize(
        std::list<char const*> const& hax0rz
      , char const* e13372[]
      , char const* outcast
    )
{
    for (
        char const** e13372_end = std::remove_copy(
            hax0rz.begin()
          , hax0rz.end()
          , e13372
          , outcast
        );
        e13372 != e13372_end;
        ++e13372
    )
    {
        std::cout << *e13372 << " is 31337." << std::endl;
    }
}
/*`
As usual, the [@http://www.sgi.com/tech/stl/remove_copy_if.html
`remove_copy_if` variant] takes in an additional function object parameter
that you can specify if you want to customize the filtering behavior.  The
requirements for this function object are the same as those of the
[link stl_primer.algorithms_example.remove `remove_if` algorithm].

[heading `transform`]
One of the most powerful algorithms at your disposal is the
[@http://www.sgi.com/tech/stl/transform.html STL `transform` algorithm];
while the `for_each` algorithm can only access or manipulate existing
elements, the `transform` algorithm can either replace elements completely
or create new elements and send them to an output iterator.  The examples
presented here do not do justice to this algorithm because they could be
reimplemented in terms of the other algorithms (albeit not as easily).

There are actually two `transform` function template overloads.  The first one
takes in an iterator range, an output iterator, and a single-argument function
object (example shown below) that will convert its argument to the return
value.
*/
class Rotate45DegreesCounterclockwise
{
    double matrix[2][2];

 public:
    Rotate45DegreesCounterclockwise()
    {
        matrix[0][0]
          = matrix[1][0]
          = matrix[1][1]
          = 0.70710678118654752440084436210485;
        matrix[0][1] = -matrix[0][0];
    }

    Point operator()(Point const& point) const
    {
        Point new_point;

        new_point.x = matrix[0][0] * point.x + matrix[0][1] * point.y;
        new_point.y = matrix[1][0] * point.x + matrix[1][1] * point.y;

        return new_point;
    }
};
/*`
Unlike the case with the [link stl_primer.algorithms_example.copy `copy`] and
[link stl_primer.algorithms_example.remove_copy `remove_copy`] algorithms, the
output iterator can point to the same element that the first input iterator
does; in this case, the transform is said to occur *in place*.
*/
void rotatePath8TimesAroundOrigin(Point path[], std::size_t length)
{
    std::cout << std::endl << "Original path: ";
    std::for_each(path, path + length, displayPoint);
    std::cout << '.' << std::endl;

    // By the end of the last iteration, the path should be back
    // at its original position.
    for (std::size_t i = 0; i < 8; ++i)
    {
        Point* path_end = std::transform(
            path
          , path + length
          , path
          , Rotate45DegreesCounterclockwise()
        );
        std::cout << "Rotated path 45 degrees: ";
        std::for_each(path, path_end, displayPoint);
        std::cout << '.' << std::endl;
    }
}
/*`
The second `transform` overload takes in /three/ input iterators, an output
iterator, and a two-argument function object (example shown below) that will
operate on the corresponding elements in each input range.
*/
std::string stringify(Sprite const& sprite, char const* name)
{
    std::string result("Sprite ");
    char sprite_id[3];

    sprintf(sprite_id, "%u", sprite.getID());
    result += sprite_id;
    result += ", ";
    result += name;

    return result;
}
/*`
The end of the second input range is assumed to be as far away from the
beginning of the range as the end of the first input range is from the
beginning of that range.  The output iterator can point to the first element
in either input range if the function object allows it to do so, or it can
just point to the first element in a different container.
*/
void combine(std::vector<Sprite> const& sprite_vector, char const* names[])
{
    std::vector<std::string> results(sprite_vector.size());
    std::vector<std::string>::const_iterator result_end = std::transform(
        sprite_vector.begin()
      , sprite_vector.end()
      , names
      , results.begin()
      , stringify
    );
    assert(
        std::distance(results.begin(), results.end()) == sprite_vector.size()
    );

    for (
        std::vector<std::string>::const_iterator result_itr = results.begin();
        result_itr != result_end;
        ++result_itr
    )
    {
        std::cout << *result_itr << std::endl;
    }
}
/*`
[heading `distance`]
It's good practice to place assertions where your code makes assumptions about
the preconditions or postconditions of certain functions or variables, such as
after the `transform` call above.  This particular assertion uses the
[@http://www.sgi.com/tech/stl/distance.html `distance` algorithm] to determine
the total of number of elements within the specified range.

[heading `random_shuffle`]
You can disorganize the contents of any container that provides
[@http://www.sgi.com/tech/stl/RandomAccessIterator.html random access] by
using the [@http://www.sgi.com/tech/stl/random_shuffle.html `random_shuffle`
algorithm].
*/
void shuffleDeck(std::deque<Card>& deck)
{
    std::random_shuffle(deck.begin(), deck.end());
    std::cout << std::endl << "Shuffled deck:";
    std::for_each(deck.begin(), deck.end(), displayCard);
    std::cout << std::endl;
}
/*`
The `random_shuffle` function template is overloaded to take in an additional
function object parameter that fulfills the following requirements:

* Be able to take in a container size as its only argument.
* Return any number between zero inclusive and the container size exclusive.
*/
#include <ctime>

std::size_t generateTimeDependentIndex(std::size_t count)
{
    return static_cast<std::size_t>(time(0)) % count;
}

void shuffleDeck(Card cards[], std::size_t size)
{
    std::random_shuffle(cards, cards + size, generateTimeDependentIndex);
    std::cout << std::endl << "Shuffled cards:";
    std::for_each(cards, cards + size, displayCard);
    std::cout << std::endl;
}
/*`
[heading `reverse`]
The inbox of almost every popular e-mail client orders its messages from the
most recently sent one to the most ancient.  We advise that you stick to
conventions like these should you ever need to implement an in-game e-mail
client.
*/
class Message
{
    static unsigned int constructed_count;
    unsigned int time_stamp;
    std::string subject;

 public:
    explicit Message(char const* s)
        : time_stamp(++constructed_count), subject(s)
    {
    }

    unsigned int getTimeStamp() const
    {
        return time_stamp;
    }

    std::string const& getSubject() const
    {
        return subject;
    }
};

unsigned int Message::constructed_count = 0;
/*`
You can reverse the current order of the contents of any container that
provides [@http://www.sgi.com/tech/stl/BidirectionalIterator.html mutable
*bidirectional iterators*]--non-`const` iterators that you can decrement as
well as increment--by using the [@http://www.sgi.com/tech/stl/reverse.html
`reverse` algorithm].
*/
void displayMessage(Message const& message)
{
    std::cout << message.getTimeStamp() << '\t' << message.getSubject();
    std::cout << std::endl;
}

void displayMessages(std::vector<Message>& messages)
{
    // Before...
    std::cout << std::endl << "In original order:" << std::endl;
    std::cout << "Time\tSubject" << std::endl;
    std::for_each(messages.begin(), messages.end(), displayMessage);

    // ...during...
    std::reverse(messages.begin(), messages.end());

    // ...and after.
    std::cout << std::endl << "In proper order:" << std::endl;
    std::cout << "Time\tSubject" << std::endl;
    std::for_each(messages.begin(), messages.end(), displayMessage);
}
/*`
You cannot use the `reverse` algorithm on a `set` or a `map` because they must
maintain their own internal ordering, so their iterators are not mutable in
that sense.

[note
General sorting algorithms are covered in a [link stl_primer.sorting_example
separate tutorial].
]
*/
//]

void fillDeck(std::deque<Card>& deck, Card::Suit suit)
{
    Card card;
    card.suit = suit;
    card.rank = 'A';
    deck.push_back(card);
    card.rank = 'K';
    deck.push_back(card);
    card.rank = 'Q';
    deck.push_back(card);
    card.rank = 'J';
    deck.push_back(card);
    card.rank = 'T';
    deck.push_back(card);

    for (char rank = '9'; rank != '1'; --rank)
    {
        card.rank = rank;
        deck.push_back(card);
    }
}

void fillDeck(std::deque<Card>& deck)
{
    fillDeck(deck, Card::DIAMOND);
    fillDeck(deck, Card::CLUB);
    fillDeck(deck, Card::HEART);
    fillDeck(deck, Card::SPADE);
}

int main()
{
    using namespace std;

    // Create sprites for the `for_each` examples.
    vector<Sprite> sprite_vector;
    for (size_t i = 0; i < 10; sprite_vector.resize(++i));
    cout << "Output all sprite IDs:" << endl;
    outputAllSpriteIDs(sprite_vector);

    Sprite sprite_array[10];
    cout << endl << "Output all sprite IDs again:" << endl;
    outputAllSpriteIDsAgain(sprite_array, sizeof(sprite_array) / sizeof(Sprite));
    cout << endl << "Output all sprite IDs...or not:" << endl;
    outputAllSpriteIDs_orNot(sprite_array);
    cout << endl;

    // Create names for the `find` example.
    list<char const*> name_list;
    name_list.push_front("Brian");
    name_list.push_front("John");
    name_list.push_front("Kevin");
    name_list.push_back("Alvin");
    name_list.push_back("Derek");
    name_list.push_back("Justin");
    name_list.push_back("Cromwell");
    name_list.push_back("Darryl");
    name_list.push_back("Kent");
    name_list.push_back("Derek");
    name_list.push_back("Justin");
    name_list.push_back("Cromwell");
    name_list.push_back("Tae");

    // Execute the `find` example.
    lookupName(name_list, "Cromwell");
    lookupName(name_list, "Crom");

    // Create cards for the `find` example with UDTs.
    deque<Card> deck;
    fillDeck(deck);

    // Execute the `find` example with UDTs.
    Card card;
    card.rank = 'K';
    card.suit = Card::HEART;
    lookupCard(deck, card);

    card.rank = 'R';
    card.suit = Card::SPADE;
    lookupCard(deck, card);

    // Create points for the `find_if` examples.
    // Each pair represents the two lowest numbers of a Pythagorean triple.
    Point p;
    list<Point> points;
    p.x = 3.0;
    p.y = 4.0;
    points.push_back(p);
    p.x = 5.0;
    p.y = 12.0;
    points.push_back(p);
    p.x = 7.0;
    p.y = 24.0;
    points.push_back(p);
    p.x = 8.0;
    p.y = 15.0;
    points.push_back(p);
    p.x = 9.0;
    p.y = 40.0;
    points.push_back(p);
    p.x = 11.0;
    p.y = 60.0;
    points.push_back(p);
    p.x = 12.0;
    p.y = 35.0;
    points.push_back(p);
    p.x = 13.0;
    p.y = 84.0;
    points.push_back(p);
    p.x = 16.0;
    p.y = 63.0;
    points.push_back(p);
    p.x = 20.0;
    p.y = 21.0;
    points.push_back(p);
    p.x = 28.0;
    p.y = 45.0;
    points.push_back(p);
    p.x = 33.0;
    p.y = 56.0;
    points.push_back(p);
    p.x = 36.0;
    p.y = 77.0;
    points.push_back(p);
    p.x = 39.0;
    p.y = 80.0;
    points.push_back(p);
    p.x = 48.0;
    p.y = 55.0;
    points.push_back(p);
    p.x = 65.0;
    p.y = 72.0;
    points.push_back(p);

    // Execute the first `find_if` example.
    p.x = sqrt(255.0);
    p.y = sqrt(3970.0);
    checkCollisionOnce(points, p);
    p.x = p.y = -1.0;
    checkCollisionOnce(points, p);

    // Create more points for the second `find_if` example.
    p.x = 15.9;
    p.y = 63.1;
    points.push_front(p);
    p.x = 8.0;
    p.y = 15.0;
    points.push_front(p);

    // Execute the second `find_if` example.
    p.x = sqrt(255.0);
    p.y = sqrt(3970.0);
    cout << endl << "Looking for multiple points:" << endl;
    checkCollision(points, p);

    // Create strings for the first `search` example.
    wordFind("Full Sail is your school!", "Sail");
    wordFind("Full Sail is your school!", "Sale");

    // Create a path for the second `search` example.
    Point path[4];
    path[0].x = sqrt(63.0);
    path[0].y = sqrt(224.0);
    path[1].x = sqrt(80.0);
    path[1].y = sqrt(1599.0);
    path[2].x = sqrt(120.0);
    path[2].y = sqrt(3599.0);
    path[3].x = sqrt(145.0);
    path[3].y = sqrt(1224.0);

    // Execute the second `search` example.
    cout << endl << "Looking for path:" << endl;
    pathFind(points, path, sizeof(path) / sizeof(Point));

    // Execute the second `search` example on a different path.
    path[3].x = sqrt(255.0);
    path[3].y = sqrt(3970.0);
    cout << endl << "Looking for another path:" << endl;
    pathFind(points, path, sizeof(path) / sizeof(Point));

    // Execute the first `transform` example.
    rotatePath8TimesAroundOrigin(path, sizeof(path) / sizeof(Point));

    // Create more cards for the `equal` and `lexicographical_compare`
    // examples.
    deque<Card> other_deck;
    fillDeck(other_deck);
    random_shuffle(deck.begin(), deck.end(), generateTimeDependentIndex);
    random_shuffle(other_deck.begin(), other_deck.end());

    // Execute the `equal` and `lexicographical_compare` examples.
    cout << endl << "Let\'s play one round of War:" << endl;
    playOneRound(deck, other_deck);

    // Create more cards for the `remove_if` examples.
    Card cards[52];
    fillDeck(deck);
    copyDeck(deck, cards);
    makeNumericalDeck(deck);
    makeNumericalDeck(cards, sizeof(cards) / sizeof(Card));

    // Create the array for the `remove_copy` example.
    char const* name_array[11];  // name_list.size() - count("Cromwell")
    cout << endl << "Filtering std::list into raw array..." << endl;
    ostracize(name_list, name_array, "Cromwell");

    // Execute the second `transform` example.
    sprite_vector.resize(11);
    cout << endl << "Combining sprites with names..." << endl;
    combine(sprite_vector, name_array);

    // Execute the `random_shuffle` examples.
    shuffleDeck(deck);
    shuffleDeck(cards, deck.size());

    // Create messages for the `reverse` example.
    vector<Message> messages;
    messages.push_back(Message("This is your mother.  Please respond."));
    messages.push_back(Message("Urgent!  Blue balls in short supply!"));
    messages.push_back(Message("The boss just called in sick."));
    messages.push_back(Message("From the desk of Rubeen al Qahal..."));
    messages.push_back(Message("Re: Interview"));

    // Execute the `reverse` example.
    displayMessages(messages);
    cout << endl;

    return 0;
}

