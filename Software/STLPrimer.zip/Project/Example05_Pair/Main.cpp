// Code by Nick E. Penney
#include <iostream>

//[pair_example_program
/*`
[heading A Container Of Two?]
Although the [@http://www.sgi.com/tech/stl/pair.html STL `pair`] is not a
[@http://www.sgi.com/tech/stl/Container.html container] by STL standards, you
can still think of it as a heterogeneous container that always holds two
elements.  A *heterogeneous container* is one that can hold completely
different types of elements--no inheritance relations or conversion
constructors necessary.  On the other hand, the STL containers are
*homogeneous*, meaning that all of their elements must be of the same type.

Also unlike the STL containers, the `pair` class template is defined in a
standard C++ header file that does /not/ have the same name:
*/
#include <utility>
/*`
Otherwise, using the `pair` class template is simplicity itself: the first
element is called `first` and the second element is called `second`.

[heading Example Program]
*/
#include <vector>

int main()
{
    std::vector<std::pair<int,char> > pairs;
    std::pair<int,char> p;

    for (char i = 0; i < 10; ++i)
    {
        p.first = i;
        p.second = 'a' + i;
        pairs.push_back(p);
    }

    std::vector<std::pair<int,char> >::iterator iter = pairs.begin();

    do
    {
        std::cout << "first: " << iter->first << "\tsecond: ";
        std::cout << iter->second << std::endl;
    }
    while (++iter != pairs.end());

    for (std::size_t loop = 0; loop < pairs.size(); ++loop)
    {
        std::cout << "first: " << pairs[loop].first << "\tsecond: ";
        std::cout << pairs[loop].second << std::endl;
    }

    return 0;
}
//]

