// Code by Cromwell D. Enage
#include <iostream>
#include <vector>
#include <list>
#include <deque>
#include <set>
#include <algorithm>

//[adaptors_example_program
/*`
[heading Rationale]
There are three primary reasons to use or to write an adaptor class:

# You need an algorithm to work with another algorithm or on top of a certain
data structure; however, the two interfaces are incompatible with each other.
# You want to reuse an existing algorithm to exhibit a different or opposite
behavior without really modifying the algorithm's implementation.
# You wish to enforce certain restrictions regarding the usage of a particular
data structure.

The [link stl_primer.functors_example Functors Tutorial] showcased several
different function object adaptors.  This tutorial will cover two other types
of adaptors provided by the STL: container adaptors and iterator adaptors.

[heading Container Adaptors]
Everybody knows that you can use a [link stl_primer.vector_example `vector`]
as a stack and either a [link stl_primer.list_example `list`] or a
[link stl_primer.deque_example `deque`] as a queue.  But it would not be wise
programming practice to do so directly.  The temptation to abuse the other
methods that the regular containers provide is almost too great, yet doing so
would very likely result in bugs that are extremely difficult to track down
and fix.  The `stack` and `queue` container adaptors attempt to prevent this
from happening by exposing only the necessary methods in their respective
public interfaces.  For both of them, the default underlying container type is
`deque`.

Everybody should also know binary trees by now.
*/
struct BinaryTreeNode
{
    char const* data;
    BinaryTreeNode* left;
    BinaryTreeNode* right;

    explicit BinaryTreeNode(char const* s) : data(s), left(0), right(0)
    {
    }

    ~BinaryTreeNode()
    {
        delete left;
        delete right;
    }
};
/*`
The four [@http://www.sgi.com/tech/stl/queue.html STL `queue`] methods shown
below are really all you need to implement any
[@http://en.wikipedia.org/wiki/FIFO first in, first out] algorithm (except
that you may also need the `size` method for comparing purposes if you want to
put a cap on the number of elements inside the queue at any given moment).
*/
#include <queue>

void breadthFirstTraverse(BinaryTreeNode* node)
{
    if (!node)
    {
        return;
    }

    std::queue<BinaryTreeNode*> node_queue;
    node_queue.push(node);

    while (!node_queue.empty())
    {
        node = node_queue.front();
        node_queue.pop();
        std::cout << ' ' << node->data;

        if (node->left)
        {
            node_queue.push(node->left);
        }

        if (node->right)
        {
            node_queue.push(node->right);
        }
    }
}
/*`
[caution
The `queue` class template also defines a `back` method.  Unless the problem
at hand explicitly asks for "the element that most recently entered the
queue", don't use it.
]

Psst!  Use a stack to traverse a binary tree pre-order /without recursion/:
*/
#include <stack>

void preOrderTraverse(BinaryTreeNode* node)
{
    std::stack<BinaryTreeNode*> node_stack;
    node_stack.push(node);

    while (!node_stack.empty())
    {
        node = node_stack.top();
        node_stack.pop();
        std::cout << ' ' << node->data;

        if (node->right)
        {
            node_stack.push(node->right);
        }

        if (node->left)
        {
            node_stack.push(node->left);
        }
    }
}
/*`
The four [@http://www.sgi.com/tech/stl/stack.html STL `stack` methods] shown
above are all you need to implement any [@http://en.wikipedia.org/wiki/LIFO
last in, first out] algorithm (plus the `size` method if you want to check or
control the number of elements at any given time).

[heading Iterator Adaptors]
The adaptors covered in the following sections can be used as
[@http://www.sgi.com/tech/stl/OutputIterator.html output iterators] for
whichever algorithms need them.  All STL iterator adaptors are defined in this
header file:
*/
#include <iterator>
/*`
[heading Output Streams As Output Iterators]
If you get tired of writing unary functions that present the contents of
arbitrary-type arguments to standard output, a more quick-and-dirty solution
would be to overload the extraction operator for each of your types.  The
extraction operator is the same as the left-shift operator, except that it
takes in a reference to the output stream as its first argument and returns
the same reference.
*/
struct Pentarnion
{
    double real;
    double i;
    double j;
    double k;
    double lmnop;

    Pentarnion() : real(0.0), i(0.0), j(0.0), k(0.0), lmnop(0.0)
    {
    }
};

template <typename CharT, typename Traits>
std::basic_ostream<CharT,Traits>&
    operator<<(std::basic_ostream<CharT,Traits>& os, Pentarnion const& p_nion)
{
    os << '[';
    os << p_nion.real;
    os << ',';
    os << p_nion.i;
    os << "i,";
    os << p_nion.j;
    os << "j,";
    os << p_nion.k;
    os << "k,";
    os << p_nion.lmnop;
    return os << "lmnop]";
}
/*`
After that, use the [@http://www.sgi.com/tech/stl/ostream_iterator.html
`ostream_iterator` adaptor] in conjunction with the `copy` algorithm to send
elements to standard output.
*/
void displayPentarnions(std::vector<Pentarnion> const& pentarnions)
{
    // The trailing comma at the end of the output is the 'dirty' part of
    // 'quick-and-dirty'.
    std::cout << std::endl << std::endl << "Pentarnions: ";
    std::copy(
        pentarnions.begin()
      , pentarnions.end()
      , std::ostream_iterator<Pentarnion>(std::cout, ", ")
//      , std::ostream_iterator<Pentarnion>(std::cout, ',')          // error
//      , std::ostream_iterator<Pentarnion const&>(std::cout, ", ")  // error
    );
}
/*`
[heading Copying Without Presizing]
The [link stl_primer.algorithms_example.copy `copy` algorithm] and related
routines impose a precondition that target container must hold enough memory
to store the copied elements; otherwise, incrementing an output iterator may
result in a memory access violation.  Both the
[@http://www.sgi.com/tech/stl/back_insert_iterator.html `back_insert_iterator`
adaptor] and the [@http://sgi.com/tech/stl/insert_iterator.html
`insert_iterator` adaptor] add elements to their underlying containers as
the elements are "assigned" to them.  The `insert_iterator` is more generic
than the `back_insert_iterator` but is also more verbose.

When defining a `set` or `map` of a custom element type without a comparator,
[@http://www.sgi.com/tech/stl/LessThanComparable.html you should overload all
four inequality operators for that element type].
*/
bool operator<(Pentarnion const& lhs, Pentarnion const& rhs)
{
    unsigned int const length = sizeof(Pentarnion) / sizeof(double);

    // One of the few legitimate uses of reinterpret_cast.
    return std::lexicographical_compare(
        reinterpret_cast<double const*>(&lhs)
      , reinterpret_cast<double const*>(&lhs) + length
      , reinterpret_cast<double const*>(&rhs)
      , reinterpret_cast<double const*>(&rhs) + length
    );
}
/*`
[caution
This type of comparison is guaranteed to work only for classes that do not
inherit from any other class and whose non-`static` data members are all
`public` and all of the same primitive type.  In most other cases, you should
explicitly use member-wise comparisons instead.
]
*/
bool operator>=(Pentarnion const& lhs, Pentarnion const& rhs)
{
    return !(lhs < rhs);
}

bool operator>(Pentarnion const& lhs, Pentarnion const& rhs)
{
    return rhs < lhs;
}

bool operator<=(Pentarnion const& lhs, Pentarnion const& rhs)
{
    return !(rhs < lhs);
}
/*`
As its name suggests, the `back_insert_iterator` adaptor always adds new
elements to the back of whatever container is passed to its constructor.  The
constructor for the `insert_iterator` adaptor, on the other hand, takes in an
additional iterator parameter referring to the desired entry position in the
container; this parameter is required even for `set` or `multiset` containers,
which use it to search for a proper insertion position more efficiently.
*/
void tripleCopy(std::vector<Pentarnion> const& pentarnions)
{
    // First copy.
    typedef std::list<Pentarnion> PentarnionList;
    PentarnionList pentarnion_list;
    std::copy(
        pentarnions.begin()
      , pentarnions.end()
      , std::back_insert_iterator<PentarnionList>(pentarnion_list)
    );
    std::cout << std::endl << std::endl << "Pentarnions: ";
    std::copy(
        pentarnion_list.begin()
      , pentarnion_list.end()
      , std::ostream_iterator<Pentarnion>(std::cout, ", ")
    );

    // Second copy.
    typedef std::deque<Pentarnion> PentarnionDeque;
    PentarnionDeque pentarnion_deque;
    std::copy(
        pentarnions.begin()
      , pentarnions.end()
      , std::insert_iterator<PentarnionDeque>(
            pentarnion_deque
          , pentarnion_deque.begin()
        )
    );
    std::cout << std::endl << std::endl << "Pentarnions: ";
    std::copy(
        pentarnion_deque.begin()
      , pentarnion_deque.end()
      , std::ostream_iterator<Pentarnion>(std::cout, ", ")
    );

    // Third copy.
    typedef std::set<Pentarnion> PentarnionSet;
    PentarnionSet pentarnion_set;
    std::copy(
        pentarnions.begin()
      , pentarnions.end()
      , std::insert_iterator<PentarnionSet>(
            pentarnion_set
          , pentarnion_set.begin()
        )
    );
    std::cout << std::endl << std::endl << "Pentarnions: ";
    std::copy(
        pentarnion_set.begin()
      , pentarnion_set.end()
      , std::ostream_iterator<Pentarnion>(std::cout, ", ")
    );
    std::cout << std::endl << std::endl;
}
//]

int main()
{
    // Create nodes for the `stack` and `queue` examples.
    BinaryTreeNode* root = new BinaryTreeNode("root");
    root->left = new BinaryTreeNode("L");
    root->right = new BinaryTreeNode("R");
    root->left->left = new BinaryTreeNode("LL");
    root->left->right = new BinaryTreeNode("LR");
    root->right->left = new BinaryTreeNode("RL");
    root->right->right = new BinaryTreeNode("RR");

    // Run the `stack` and `queue` examples.
    std::cout << "Breadth-first traversal:";
    breadthFirstTraverse(root);
    std::cout << std::endl << "Pre-order traversal:";
    preOrderTraverse(root);

    // Clean up all nodes.
    delete root;

    // Create 5-D rotation data for the iterator adaptor examples.
    Pentarnion pentarnion;
    std::vector<Pentarnion> pentarnions;
    pentarnion.lmnop = 1.0;
    pentarnions.push_back(pentarnion);
    pentarnion.k = 1.0;
    pentarnions.push_back(pentarnion);
    pentarnion.j = 1.0;
    pentarnions.push_back(pentarnion);
    pentarnion.i = 1.0;
    pentarnions.push_back(pentarnion);
    pentarnion.real = 1.0;
    pentarnions.push_back(pentarnion);
    pentarnion.lmnop = 0.0;
    pentarnions.push_back(pentarnion);
    pentarnion.k = 0.0;
    pentarnions.push_back(pentarnion);
    pentarnion.j = 0.0;
    pentarnions.push_back(pentarnion);
    pentarnion.i = 0.0;
    pentarnions.push_back(pentarnion);

    // Run the iterator adaptor examples.
    displayPentarnions(pentarnions);
    tripleCopy(pentarnions);

    return 0;
}

