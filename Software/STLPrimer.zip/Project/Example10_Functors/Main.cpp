// Code by Cromwell D. Enage
#include <iostream>
#include <iomanip>

// The std::transform algorithm is here to stay.
#pragma warning(disable: 4996)

//[functors_example_program
/*`
[heading Coming To Terms]
Although the terms *function object* and *functor* are considered
[@http://www.sgi.com/tech/stl/functors.html synonymous], the definition that
we are accustomed to is only a subset of the formal definition, which
[link stl_primer.set_example.function_objects we will repeat here]:

* an ordinary function.
* a function pointer.
* an instance of a class that defines the function call operator as one of its
members.

We will reserve the word *functor* for function objects that fulfill the last
definition, as they will be the focus of this tutorial.  Unlike the APIs
featured in other tutorials, these functor classes are mostly defined by
/you/, the user; however, the STL /does/ provide several adaptors that present
function object interfaces on top of other operators or other functor classes,
including your own.

[heading Functions With State]
Let's say that you're developing a real-time strategy game in which each
army's economy relies partially on one or more banking systems.  You could
calculate an army's bank profits using the *compound interest equation*:
*/
#include <cmath>

double
    computeProfit(
        double initial_deposit
      , double interest_rate
      , unsigned int n  // # of times interest is compounded per time unit
      , double time_slice  // current game turn period, in terms of time unit
    )
{
    // The C++ Standard mandates the math functions to be defined
    // in this namespace, but Microsoft keeps them in global scope.
    using namespace std;

    return initial_deposit * pow(1 + interest_rate / n, n * time_slice);
}
/*`
If the bank makes payments only once every thousand or so turns, you could use
the *simplified compound interest equation*:
*/
double
    computeSimplifiedProfit(
        double initial_deposit
      , double interest_rate
    )
{
    return initial_deposit * (1 + interest_rate);
}
/*`
On the other hand, this being a real-time strategy game, you are more likely
to use the *continuous compound interest equation*:
*/
double
    computeContinuousProfit(
        double initial_deposit
      , double interest_rate
      , double time_slice
    )
{
    using namespace std;
    return initial_deposit * exp(interest_rate * time_slice);
}
/*`
As each army's profit is computed, a few parameters will be bound to the same
values.  For testing purposes, these values should be easily configurable,
meaning that each value should be stored in some persistent variable.  Global
or static member variables are actually too restrictive to use here, however:
several groups of armies may rely on different economic systems that should
still be able to use the same underlying function, and variables of such large
scope would hamper or prevent these systems from running concurrently.  The
solution is to define a functor class that would hold these variables and
pass their values to the underlying function when needed; each economic system
could then just initialize one functor with each desired combination of values
for these variables.

So, when designing a functor class on top of an existing function, determine
at least three things:

# Which of the existing function parameters will remain constant throughout?
# Which parameters will remain constant across all armies during a game turn?
# Which parameters will be bound to different values for each army?

Parameters in the first group should become member variables that are
initialized upon construction of the functor.  Parameters in the second group
should become member variables that are initialized by some type of update
method.  Parameters in the last group should be passed in as parameters to the
function call operator.

For the sake of simplicity, we will store the armies' bank deposits in one
container while keeping track of their interest rates in another container;
furthermore, we will not worry about decimal-place rounding rules with regard
to transactions and so on.  What does matter is that the initial deposit and
the interest rate will remain as function parameters; what happens to the
other variables will depend on which compound interest policy we decide to
implement.  Both the regular and continuous compound interest policies rely on
a time slice that will be updated during each game turn.  The value of the `n`
parameter for the regular equation is likely to stay the same throughout, so
the functor that calculates the regular compound interest will initialize it
once.
*/
class ProfitCalculator
{
    unsigned int number_of_times_compounded;
    double time_slice;

 public:
    explicit ProfitCalculator(unsigned int n)
        : number_of_times_compounded(n), time_slice(0.0)
    {
    }

    void update(double time_slice)
    {
        this->time_slice = time_slice;
    }

    double operator()(double initial_deposit, double interest_rate) const
    {
        return computeProfit(
            initial_deposit
          , interest_rate
          , number_of_times_compounded
          , time_slice
        );
    }
};
/*`
The functor that calculates the continuous compound interest doesn't need to
handle any other parameters that were part of the original equation.  Since
its member variables are of primitive times, we can make do without defining
a constructor here.
*/
class ContinuousProfitCalculator
{
    double time_slice;

 public:
    void update(double time_slice)
    {
        this->time_slice = time_slice;
    }

    double operator()(double initial_deposit, double interest_rate) const
    {
        return computeContinuousProfit(
            initial_deposit
          , interest_rate
          , time_slice
        );
    }
};
/*`
With this setup, we can use the [link stl_primer.algorithms_example.transform
`transform` algorithm] to update each army's income according to its interest
rate and whichever profit calculation policy is in effect.  The functor is
also updated each turn to hold a time slice that varies moderately.
*/
#include <cstdlib>
#include <vector>
#include <algorithm>

void
    runArmyBanks(
        char const* army[]
      , unsigned int const army_count
      , double initial_deposit[]
      , double interest_rate[]
      , unsigned int number_of_game_turns
    )
{
    std::vector<double>
        income(initial_deposit, initial_deposit + army_count);
    ProfitCalculator
        calculateProfits(20);

    for (unsigned int i = 0; i < army_count; ++i)
    {
        std::cout << "\t\t" << army[i];
    }

    for (;;)
    {
        std::cout << std::endl << "Turns left: " << number_of_game_turns;

        for (unsigned int i = 0; i < army_count; ++i)
        {
            std::cout << '\t' << income[i];
        }

        if (number_of_game_turns)
        {
            calculateProfits.update((rand() % 40 + 80) * 0.01);
            std::transform(
                income.begin()
              , income.end()
              , interest_rate
              , income.begin()
              , calculateProfits
            );
            --number_of_game_turns;
        }
        else
        {
            std::cout << std::endl << std::endl;
            break;
        }
    }
}
/*`
You can see that editing the code to change from one policy to another
requires much less effort since we planned ahead.
*/
void
    runArmyBanksSimply(
        char const* army[]
      , unsigned int const army_count
      , double initial_deposit[]
      , double interest_rate[]
      , unsigned int number_of_game_turns
    )
{
    std::vector<double>
        income(initial_deposit, initial_deposit + army_count);

    for (unsigned int i = 0; i < army_count; ++i)
    {
        std::cout << "\t\t" << army[i];
    }

    for (;;)
    {
        std::cout << std::endl << "Turns left: " << number_of_game_turns;

        for (unsigned int i = 0; i < army_count; ++i)
        {
            std::cout << '\t' << income[i];
        }

        if (number_of_game_turns)
        {
            std::transform(
                income.begin()
              , income.end()
              , interest_rate
              , income.begin()
              , computeSimplifiedProfit
            );
            --number_of_game_turns;
        }
        else
        {
            std::cout << std::endl << std::endl;
            break;
        }
    }
}
/*`
Note that we didn't need to make a separate functor class for the routine
above.
*/
void
    runArmyBanksContinuously(
        char const* army[]
      , unsigned int const army_count
      , double initial_deposit[]
      , double interest_rate[]
      , unsigned int number_of_game_turns
    )
{
    std::vector<double>
        income(initial_deposit, initial_deposit + army_count);
    ContinuousProfitCalculator
        calculateProfits;       // only changes here

    for (unsigned int i = 0; i < army_count; ++i)
    {
        std::cout << "\t\t" << army[i];
    }

    for (;;)
    {
        std::cout << std::endl << "Turns left: " << number_of_game_turns;

        for (unsigned int i = 0; i < army_count; ++i)
        {
            std::cout << '\t' << income[i];
        }

        if (number_of_game_turns)
        {
            calculateProfits.update((rand() % 40 + 80) * 0.01);
            std::transform(
                income.begin()
              , income.end()
              , interest_rate
              , income.begin()
              , calculateProfits
            );
            --number_of_game_turns;
        }
        else
        {
            std::cout << std::endl << std::endl;
            break;
        }
    }
}
/*`
[heading Adaptable Functors]
The [link stl_primer.algorithms_example.find_if `find_if` example] used the
`Point` and `InCloseProximity` classes to search for all positions that were
in close proximity to a certain location.  Now, we would like to reuse these
two classes for the same task, but this time we will use the
[link stl_primer.algorithms_example.remove_copy_if `remove_copy_if` algorithm]
to obtain the desired subset of positions.

We can leave the `Point` structure unaltered.
*/
struct Point
{
    double x;
    double y;
};
/*`
The `InCloseProximity` class is another story.  The `remove_copy_if` algorithm
/excludes/ the elements fulfilling the specified predicate from going into the
target container.  We could add a flag that toggles the inequality comparison
between less-than and greater-than, but that would probably mean changing the
constructor interface.  If lots of other code is calling this constructor
directly, an interface change may be unacceptable.

Ideally, you would construct some type of functor class on top of the one you
just wrote.  The STL already provides such a utility, but first it requires
your class to be an [@http://www.sgi.com/tech/stl/AdaptablePredicate.html
*adaptable predicate*] because the utility needs to know the proper parameter
and return types.  Since `InCloseProximity` is already a
[@http://www.sgi.com/tech/stl/UnaryPredicate.html *unary predicate*], all you
have to do is to add two type definitions in `public` scope: an unqualified
`argument_type` representing the parameter type, and a `result_type`
representing the return type `bool`.
*/
class InCloseProximity
{
    Point location;
    double radius_squared;

 public:
    typedef Point argument_type;  // not `Point const&`
    typedef bool result_type;

    InCloseProximity(Point const& p, double r)
        : location(p), radius_squared(r * r)
    {
    }

    result_type operator()(argument_type const& p) const
    {
        double dx = location.x - p.x;
        double dy = location.y - p.y;

        // Since we're only comparing relative distances,
        // we don't need to perform a square root operation here.
        return dx * dx + dy * dy < radius_squared;
    }
};
/*`
[heading Function Object Adaptors]
A *function object adaptor* transforms an existing function object into one
with a more suitable interface or behavior.  The adaptor we need here is the
[@http://www.sgi.com/tech/stl/unary_negate.html `unary_negate` class
template], a function object adaptor that is itself a unary predicate.  If you
wish to create an instance of the adaptor that will only last the lifetime of
an algorithm, you can just pass your functor as an argument to the `not1`
convenience function, which returns an object of the desired type.
*/
#include <functional>  // std::unary_negate, std::not1
#include <list>
#include <algorithm>

void displayPoint(Point const& p)
{
    std::cout << "[x=" << p.x << ",y=" << p.y << ']';
}

void checkCollision(std::list<Point> const& points, Point const& p)
{
    InCloseProximity in_close_proximity(p, 0.5);

    // Make room for copied elements.
    std::list<Point> collided(points.size());

    // Copy the points, excluding the ones not in close proximity to `p`.
    // Remove any unused Point objects from `collided` via the `erase` method.
    collided.erase(
        std::remove_copy_if(
            points.begin()
          , points.end()
          , collided.begin()
          , std::not1(in_close_proximity)
        )
      , collided.end()
    );

    // Output.
    std::cout << "Target position: ";
    displayPoint(p);
    std::cout << std::endl << "Out of ";
    std::for_each(points.begin(), points.end(), displayPoint);
    std::cout << ',' << std::endl << "  points ";
    std::for_each(collided.begin(), collided.end(), displayPoint);
    std::cout << " are close enough." << std::endl << std::endl;
}
/*`
The [@http://www.sgi.com/tech/stl/binary_negate.html `binary_negate` function
object adaptor] and the `not2` convenience function work the same way for
[@http://www.sgi.com/tech/stl/AdaptableBinaryPredicate.html *adaptable binary
predicates*].

[heading Adaptable Function Pointers]
Recall that the [link stl_primer.algorithms_example.find first `find` example]
used straight pointer equality to look up names of type `char const*`.  A much
better way would be to invoke `find_if` in conjunction with the C standard
function `strcmp`, but `strcmp` returns zero upon encountering two equal
C-style strings.  We would like to wrap a `unary_negate` around `strcmp`
directly, but we cannot modify `strcmp` to make it an adaptable predicate.

Fortunately, there is a way to use `strcmp` inside `find_if` without resorting
to writing a helper function object:

# The [@http://www.sgi.com/tech/stl/ptr_fun.html `ptr_fun` function template]
takes in a pointer to either a unary function or a binary function and
converts it to a [@http://www.sgi.com/tech/stl/pointer_to_unary_function.html
`pointer_to_unary_function`] object or a
[@http://www.sgi.com/tech/stl/pointer_to_binary_function.html
`pointer_to_binary_function`] object, respectively.
# Both the [@http://www.sgi.com/tech/stl/binder1st.html `bind1st` function
template] and the [@http://www.sgi.com/tech/stl/binder2nd.html `bind2nd`
function template] convert
[@http://www.sgi.com/tech/stl/AdaptableBinaryFunction.html *adaptable binary
functions*] to [@http://www.sgi.com/tech/stl/AdaptableUnaryFunction.html
*adaptable unary functions*].  The only difference is that the second argument
to `bind1st` is always the /first/ argument to the underlying binary function,
while the second argument to `bind2nd` is always the second argument.

Now, `find_if` doesn't care that the return type of `strcmp` isn't `bool`.  It
only cares that `strcmp` and friends can be used inside a boolean expression.
*/
#include <cstring>
#include <functional>  // std::ptr_fun, std::bind1st, std::bind2nd, std::not1
#include <algorithm>

void lookupName(std::list<char const*> const& names, char const* name)
{
    if (
        std::find_if(
            names.begin()
          , names.end()
          , std::not1(std::bind2nd(std::ptr_fun(strcmp), name))
        )
     == names.end()
    )
    {
        std::cout << name << " is not in the list." << std::endl;
    }
    else
    {
        std::cout << name << " is in the list." << std::endl;
    }
}
/*`
[heading Operator Adaptors]
The STL comes with a group of self-explanatory functors wrapped around the
corresponding operators.  For performing arithmetic:

* [@http://www.sgi.com/tech/stl/plus.html `plus`]
* [@http://www.sgi.com/tech/stl/minus.html `minus`]
* [@http://www.sgi.com/tech/stl/times.html `multiplies`]
* [@http://www.sgi.com/tech/stl/divides.html `divides`]
* [@http://www.sgi.com/tech/stl/modulus.html `modulus`]
* [@http://www.sgi.com/tech/stl/negate.html `negate`]

To make comparisons:

* [@http://www.sgi.com/tech/stl/equal_to.html `equal_to`]
* [@http://www.sgi.com/tech/stl/not_equal_to.html `not_equal_to`]
* [@http://www.sgi.com/tech/stl/greater.html `greater`]
* [@http://www.sgi.com/tech/stl/less.html `less`]
* [@http://www.sgi.com/tech/stl/greater_equal.html `greater_equal`]
* [@http://www.sgi.com/tech/stl/less_equal.html `less_equal`]

For logic operations:

* [@http://www.sgi.com/tech/stl/logical_and.html `logical_and`]
* [@http://www.sgi.com/tech/stl/logical_or.html `logical_or`]
* [@http://www.sgi.com/tech/stl/logical_not.html `logical_not`]

Sorry, the STL does not provide functors for bitwise operations.  Feel free to
write your own functors: don't let standards inhibit you.  Learn this lesson
well: [@http://www.ddj.com/architect/184401912 to use the STL is to extend
it].  Maintain this mindset, and you will reduce the amount of frustration
that comes with discovering that a piece of much-needed functionality seems to
be missing from the STL.  At any rate, unless you regularly overload operators
for container element types--or you're trying to engineer some sort of math
library--you shouldn't have to use these particular functors often.
*/
//]

int main()
{
    // Showcase functors.
    char const* army[] = {"Blue", "Green", "Tan"};
    double deposit[] = {1500.000001, 1200.000001, 1000.000001};
    double interest_rate[] = {0.06, 0.075, 0.09};
    unsigned int const army_count = sizeof(army) / sizeof(char const*);

    std::cout << std::setprecision(10);
    runArmyBanks(army, army_count, deposit, interest_rate, 12);
    std::cout << "Using simplified compound interest equation:" << std::endl;
    runArmyBanksSimply(army, army_count, deposit, interest_rate, 12);
    std::cout << "Using continuous compound interest equation:" << std::endl;
    runArmyBanksContinuously(army, army_count, deposit, interest_rate, 12);

    // Showcase adaptable functors.
    Point p;
    std::list<Point> points;
    p.x = 1.2;
    p.y = 3.7;
    points.push_back(p);
    p.x = 6.25;
    p.y = 5.0;
    points.push_back(p);
    p.x = 1.3;
    p.y = 3.8;
    points.push_back(p);
    p.x = p.y = 0.0;
    points.push_back(p);
    p.x = 1.25;
    p.y = 3.75;
    checkCollision(points, p);

    // Showcase adaptable function pointers.
    std::list<char const*> name_list;
    name_list.push_front("Brian");
    name_list.push_front("John");
    name_list.push_front("Kevin");
    name_list.push_back("Alvin");
    name_list.push_back("Derek");
    name_list.push_back("Justin");
    name_list.push_back("Cromwell");
    name_list.push_back("Darryl");
    name_list.push_back("Kent");
    name_list.push_back("Derek");
    name_list.push_back("Justin");
    name_list.push_back("Cromwell");
    name_list.push_back("Tae");
    lookupName(name_list, "Alvin");
    lookupName(name_list, "Al");
    std::cout << std::endl;

    return 0;
}

