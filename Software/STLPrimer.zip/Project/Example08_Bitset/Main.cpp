// Code by Cromwell D. Enage
#include <cassert>
#include <iostream>

//[bitset_example_program
/*`
[heading Rationale]
The [@http://www.sgi.com/tech/stl/bitset.html STL `bitset`] is a data type
that resembles an unsigned integer when used in bitwise operations.  Its main
advantage over unsigned integers is increased code readability.  One common
use case involves inventories.

[heading Example Program]
*/
#include <bitset>

class Example
{
    enum Toy {
        POGO_STICK
      , KILI_KILI_FEATHER
      , MEGA_SOAKER
      , WATER_BALLOON
      , ROTTEN_EGG
      , CHERRY_BOMB
      , LASSO_LAUNCHER
      , DUCT_TAPE_RIFLE
      , GUM_WAD_DISPENSER
      , WHOOPEE_TURRET
      , TOY_COUNT  // number of enum values
    };

    typedef std::bitset<TOY_COUNT> ToySet;

    ToySet inventory;
    char const* name[TOY_COUNT];

    // A few common inventory operations.
    void pickup(Toy toy);
    void drop(Toy toy);
    void pickup(ToySet const& toys);
    void drop(ToySet const& toys);
    void enumeratePossessions() const;

 public:
    Example();
};
/*`
To turn on a specific bit, you can use either the bracket operator or one of
the `set` method overloads that takes in the position of the bit.
*/
void Example::pickup(Toy toy)
{
    std::cout << "...Picking up " << name[toy] << "..." << std::endl;

    // The following statements are equivalent.
#if 1
    // Here is the way to turn on a bit for an unsigned integer.
    inventory |= 1 << toy;
#elif 1
    inventory[toy] = true;
#elif 1
    inventory.set(toy);
#else
    inventory.set(toy, true);
#endif
}
/*`
To turn off a specific bit, you can use either the bracket operator, the
single-argument `reset` method overload, or the two-argument `set` method
overload.
*/
void Example::drop(Toy toy)
{
    std::cout << "...Dropping " << name[toy] << "..." << std::endl;

#if 1
    // Here is the way to turn off a bit for an unsigned integer.
    inventory &= ~(1 << toy);
#elif 1
    inventory[toy] = false;
#elif 1
    inventory.reset(toy);
#else
    inventory.set(toy, false);
#endif
}
/*`
You can use either the bracket operator or the `test` method to check which
bits are turned on or off.
*/
void Example::pickup(ToySet const& toys)
{
    assert(
        (toys.size() == TOY_COUNT)
     && "Something is wrong with the std::bitset implementation."
    );

    for (std::size_t i = 0; i < toys.size(); ++i)
    {
        if (!inventory[i] && toys.test(i))
        {
            std::cout << "...Picking up " << name[i] << "..." << std::endl;
        }
    }

    // Same as turning on several bits for an unsigned integer.
    inventory |= toys;
}

void Example::drop(ToySet const& toys)
{
    assert(
        (toys.size() == inventory.size())
     && "Something is wrong with the std::bitset implementation."
    );

    for (std::size_t i = 0; i < toys.size(); ++i)
    {
        if (inventory[i] && toys.test(i))
        {
            std::cout << "...Dropping " << name[i] << "..." << std::endl;
        }
    }

    // Same as turning off several bits for an unsigned integer.
    inventory &= ~toys;
}
/*`
The `bitset` is not a [@http://www.sgi.com/tech/stl/Container.html container]
that provides `begin` and `end` methods; however, you can still enumerate the
bits via the bracket operator or the `test` method.  In addition, you can send
the entire bitset directly to standard output, if necessary.
*/
void Example::enumeratePossessions() const
{
    assert(
        (inventory.size() == TOY_COUNT)
     && "Something is wrong with the std::bitset implementation."
    );

    std::cout << std::endl << "Number of toys in inventory: ";
    std::cout << inventory.count() << std::endl;

    for (std::size_t i = 0; i < inventory.size(); ++i)
    {
        if (inventory[i])
        {
            std::cout << "We carry the " << name[i] << '.' << std::endl;
        }
        else// if (!inventory.test(i))
        {
            std::cout << "We seek the " << name[i] << '.' << std::endl;
        }
    }

    std::cout << "Bits are " << inventory << ", decimal value is ";
    std::cout << inventory.to_ulong() << '.' << std::endl << std::endl;
}
/*`
Our `bitset` example program will now manipulate the inventory.
*/
Example::Example()
{
    // The `name` variable is not a static member,
    // so elements must be initialized in the constructor body.
    name[POGO_STICK] = "Pogo Stick";
    name[KILI_KILI_FEATHER] = "Kili-Kili Feather";
    name[MEGA_SOAKER] = "Mega-Soaker";
    name[WATER_BALLOON] = "Water Balloon";
    name[ROTTEN_EGG] = "Rotten Egg";
    name[CHERRY_BOMB] = "Cherry Bomb";
    name[LASSO_LAUNCHER] = "Lasso Launcher";
    name[DUCT_TAPE_RIFLE] = "Duct Tape Rifle";
    name[GUM_WAD_DISPENSER] = "Gum Wad Dispenser";
    name[WHOOPEE_TURRET] = "Whoopee Turret";

    // The following statements are equivalent.
#if 1
    // Notice that you can chain certain `bitset` methods in one expression.
    pickup(ToySet().set(GUM_WAD_DISPENSER).set(WHOOPEE_TURRET));
#else
    pickup(ToySet(1 << GUM_WAD_DISPENSER) | ToySet(1 << WHOOPEE_TURRET));
#endif

    pickup(KILI_KILI_FEATHER);
    enumeratePossessions();
    drop(KILI_KILI_FEATHER);

    // The following statements are equivalent.
#if 1
    drop(ToySet().set(GUM_WAD_DISPENSER).set(DUCT_TAPE_RIFLE));
#else
    drop(ToySet(1 << GUM_WAD_DISPENSER) | ToySet(1 << DUCT_TAPE_RIFLE));
#endif

    enumeratePossessions();
    std::cout << "...Toggling inventory..." << std::endl;

    for (std::size_t i = 0; i < TOY_COUNT; ++i)
    {
        // The following statements are equivalent.
#if 1
        inventory.flip(i);
#else
        inventory ^= 1 << i;
#endif
    }

    enumeratePossessions();
    std::cout << "...Toggling inventory back..." << std::endl;

    // The following statement is equivalent to the previous `for` loop.
    inventory.flip();
    enumeratePossessions();

    // The zero-argument `set` method overload turns on all bits.
    std::cout << "...Picking up all toys..." << std::endl;
    inventory.set();
    enumeratePossessions();

    // The zero-argument `reset` method overload turns off all bits.
    std::cout << "...Dropping all toys..." << std::endl;
    inventory.reset();
    enumeratePossessions();
}
/*`
You can also left-shift and right-shift `bitset` objects directly; they just
weren't necessary in the example.  The semantics are the same as with unsigned
integers.
*/
//]

int main()
{
    Example example;

    return 0;
}

