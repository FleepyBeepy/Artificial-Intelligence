// Code by Cromwell D. Enage
#include <iostream>

//[string_example_program
/*`
[heading Rationale]
The [link stl_primer.set_example Set Tutorial] exposed a few shortcomings with
C-style strings that make their usage as container elements cumbersome.  The
`string` data type was designed to address these shortcomings.
*/
#include <string>

void helloStrings()
{
    // The conversion constructor that takes in C-style strings.
    std::string s1("Hello");

    // A more convenient form of string initialization.
    std::string s2 = "World";

    // Don't forget: assignment operators return the objects themselves.
    std::cout << (s1 += ' ') << std::endl;

    // Same as the addition assignment operator that takes in characters.
    s2.push_back(',');

    // String concatenation.
    std::cout << (s2 += " this is Full Sail!") << std::endl;

    // Same as the addition assignment operator that takes in strings,
    // C-style or otherwise.
    std::cout << s1.append(s2) << std::endl << std::endl;
}
/*`
[heading Example Program]
We will now modify the procedural interface for [link stl_primer.set_example
the `set` example program] so that the container holds `string` elements;
notice that we no longer need a [link stl_primer.functors_example function
object] to perform string comparisons.
*/
#include <set>

typedef std::set<std::string> Names;

void print(Names const& names);
void search(Names const& names, char const* name);
void search2(Names const& names, char const* name);
void remove(Names& names, char const* name);
/*`
Aside from the default-constructor invocation, the rest of the interface and
its implementation are exactly the same.
*/
int main()
{
    helloStrings();

    Names names;

    names.insert("echo");
    names.insert("bravo");
    names.insert("alpha");
    names.insert("charlie");
    names.insert("foxtrot");
    names.insert("echo");
    names.insert("golf");
    print(names);

    search(names, "echo");
    remove(names, "echo");
    print(names);
    search(names, "echo");
    remove(names, "echo");

    names.erase(names.begin());
    print(names);

    return 0;
}
/*`
[note
The `string` data type is actually a type definition that stands for
[@http://www.sgi.com/tech/stl/basic_string.html `basic_string<char>`].  Unless
you need to process text in a language other than English--e.g. because the
`char` element type is insufficient to represent certain alphabets--you should
not have to explicitly instantiate a `basic_string`.
]
*/
//]

void print(Names const& names)
{
    for (Names::const_iterator itr = names.begin(); itr != names.end(); ++itr)
    {
        std::cout << ' ' << *itr;
    }

    std::cout << std::endl;
}

void search(Names const& names, char const* name)
{
    if (names.find(name) == names.end())
    {
        std::cout << name << " is not in the set." << std::endl;
    }
    else
    {
        std::cout << name << " is in the set." << std::endl;
    }
}

void search2(Names const& names, char const* name)
{
    Names::const_iterator itr = names.find(name);

    if (itr == names.end())
    {
        std::cout << name << " is not in the container." << std::endl;
    }
    else
    {
        do
        {
            std::cout << *itr << " is in the container." << std::endl;
        }
        while (++itr != names.end());
    }
}

void remove(Names& names, char const* name)
{
    std::cout << names.erase("echo") << " element(s) erased." << std::endl;
}

