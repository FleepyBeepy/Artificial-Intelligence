// Code by Cromwell D. Enage
#include <iostream>

//[sorting_example_program
/*`
[heading Ordered Data]
The easiest way to organize data is to impose the proper ordering on them;
integers are sorted in ascending or descending order, words are sorted in
lexicographical order, etc.  The [@http://www.sgi.com/tech/stl/ STL] places
several tools at your disposal to meet your ordering needs.

[heading Sorted Containers]
Games that feature competition typically display tables of high scores that
players make in a certain time period.  An arcade-style high-score table
keeps track of only scores and names, usually in descending order (unless the
scoring system is similar to the one used in golf).  The
[@http://www.sgi.com/tech/stl/multimap.html STL `multimap`] is well-suited to
this type of use case.  Its interface is almost the same as that of the
[link stl_primer.map_example STL `map`], which could also sort name-score
pairs by key but would not allow more than one entry to have the same score.
*/
#include <map>

void sortScores(char const* names[], std::size_t scores[], std::size_t count)
{
    // Use the score as the key and the name as the value.
    typedef std::multimap<std::size_t,char const*> HighScores;

    HighScores high_scores;

    for (std::size_t i = 0; i < count; ++i)
    {
        // The STL multimap does not define the bracket operator.
        high_scores.insert(HighScores::value_type(scores[i], names[i]));
    }

    std::cout << "NDT Score\tName" << std::endl;

    // The default comparator sorts the name-score pairs in ascending order,
    // so a correct high-score display must iterate backwards through the map.
    // All C++ standard containers (not `slist`) provide this ability.
    for (
        HighScores::const_reverse_iterator itr = high_scores.rbegin();
        itr != high_scores.rend();
        ++itr
    )
    {
        std::cout << itr->first << "\t\t" << itr->second << std::endl;
    }
}
/*`
[note
All ports of the [@http://gcc.gnu.org/ G++] 3.3.x and 3.4.x compiler series
have a [@http://gcc.gnu.org/bugzilla/show_bug.cgi?id=11729 bug] that will
prevent you from using a `const_reverse_iterator` to iterate through a
`multimap`.  The workaroud is to use a `reverse_iterator` instead.  The bug
is fixed in versions 4.1 and later.
]

[heading Equivalent But Not Equal]
By default, if you insert a key-value pair into a `multimap` and then insert
another pair with the same key, the comparator will treat them as equivalent,
so these pairs may appear in any order with respect to each other during
iteration through the `multimap`.  If the order of eqivalent elements is also
important, then you must impose your own ordering.  In the high-score example,
each person who makes a certain score should place higher than the next person
to make the same score.  One way to help you enforce this policy is to
maintain a timestamp of all score entries created.
*/
class ScoreEntry
{
    static std::size_t time_stamp;
    char const* name;
    std::size_t time_created;
    std::size_t score;

 public:
    ScoreEntry(char const* s, std::size_t n)
        : name(s), time_created(++time_stamp), score(n)
    {
    }

    char const* getName() const
    {
        return name;
    }

    std::size_t getTimeCreated() const
    {
        return time_created;
    }

    std::size_t getScore() const
    {
        return score;
    }
};

std::size_t ScoreEntry::time_stamp = 0;
/*`
If you want to use operator overloading to impose your own ordering,
[@http://www.sgi.com/tech/stl/LessThanComparable.html you should overload all
four inequality operators].
*/
bool operator<(ScoreEntry const& lhs, ScoreEntry const& rhs)
{
    if (lhs.getScore() < rhs.getScore())
    {
        // Sort by score...
        return true;
    }
    else if (lhs.getScore() == rhs.getScore())
    {
        // ...then by chronology (oldest to newest).
        return rhs.getTimeCreated() < lhs.getTimeCreated();
    }
    else
    {
        return false;
    }
}

bool operator>=(ScoreEntry const& lhs, ScoreEntry const& rhs)
{
    return !(lhs < rhs);
}

bool operator>(ScoreEntry const& lhs, ScoreEntry const& rhs)
{
    return rhs < lhs;
}

bool operator<=(ScoreEntry const& lhs, ScoreEntry const& rhs)
{
    return !(rhs < lhs);
}
/*`
Since the `ScoreEntry` data type encapsulates both the name and the score,
the [link stl_primer.set_example STL `set`] will suffice as a container.
*/
#include <vector>
#include <set>

void
    sortScores(
        std::vector<char const*> const& names
      , std::vector<std::size_t> const& scores
    )
{
    typedef std::set<ScoreEntry> HighScores;

    HighScores high_scores;
    std::size_t count = names.size();

    for (std::size_t i = 0; i < count; ++i)
    {
        high_scores.insert(ScoreEntry(names[i], scores[i]));
    }

    std::cout << "Time\tName\t\t\t\tNDT Score" << std::endl;

    // Again, iterate backwards to display the high scores in correct order.
    for (
        HighScores::const_reverse_iterator itr = high_scores.rbegin();
        itr != high_scores.rend();
        ++itr
    )
    {
        std::cout << itr->getTimeCreated() << '\t' << itr->getName() << '\t';
        std::cout << itr->getScore() << std::endl;
    }
}
/*`
[heading Merge Sort]
Another way to enforce the equal-score policy is to use a sorting /algorithm/
rather than a [link stl_primer.sorting_example.sorted_containers sorted
container]: namely, one of the [@http://www.sgi.com/tech/stl/stable_sort.html
`stable_sort` function template overloads].  Their implementations use the
*merge sort* algorithm defined in
[@http://www.amazon.com/Art-Computer-Programming-Sorting-Searching/dp/0201896850/ref=pd_bbs_6?ie=UTF8&s=books&qid=1195534683&sr=8-6
/The Art of Computer Programming. Volume 3: Sorting and Searching/ by Donald
E. Knuth]; this algorithm has the important property where eqivalent elements
retain the order that they were in with respect to each other before being
sorted.  One consequence of this behavior is that we can use the /insertion
order/ of our name-score pairs to sort those that have the same score value;
however, we must now sort all other name-score pairs in /descending order/.
*/
#include <utility>

bool
    compareNameScorePairs(
        std::pair<char const*,std::size_t> const& lhs
      , std::pair<char const*,std::size_t> const& rhs
    )
{
    return rhs.second < lhs.second;
}
/*`
Like all [link stl_primer.algorithms_example STL algorithms], `stable_sort`
takes in a pair of [@http://www.sgi.com/tech/stl/InputIterator.html *input
iterators*].  We will invoke the overload that also takes in our comparator
function.
*/
#include <algorithm>

void
    sortScoresAgain(
        std::vector<char const*> const& names
      , std::vector<std::size_t> const& scores
    )
{
    typedef std::pair<char const*,std::size_t> NameScorePair;
    typedef std::vector<NameScorePair> HighScores;

    HighScores high_scores;

    for (std::size_t i = 0; i < names.size(); ++i)
    {
        high_scores.push_back(NameScorePair(names[i], scores[i]));
    }

    std::stable_sort(
        high_scores.begin()
      , high_scores.end()
      , compareNameScorePairs
    );
    std::cout << "Name\t\t\t\tNDT Score" << std::endl;

    // Name-score pairs are now in the 'correct' order.
    for (
        HighScores::const_iterator itr = high_scores.begin();
        itr != high_scores.end();
        ++itr
    )
    {
        std::cout << itr->first << '\t' << itr->second << std::endl;
    }
}
/*`
The order of the name-score pairs shown should now be the same as that of our
[link stl_primer.sorting_example.equivalent_but_not_equal second `sortScores`
routine].

[note
When using the Visual Studio IDE, building a console application with source
code that calls `stable_sort` also builds an export library.
]

To inhibit this behavior:

# Bring up the Properties dialog box.
# Select the "Debug" configuration.
# In the tree-view on the left, expand "Configuration Properties" and "C++",
then Select "Code Generation".
# In the list-view on the right, at the "Runtime Library" row, click on the
entry to the right and select "Multi-Threaded Debug (/MTd)" from the drop-down
menu.
# Click the "Apply" button, then select the "Release" configuration.
# At the "Runtime Library" row, click on the entry to the right and select
"Multi-Threaded (/MT)" from the drop-down menu.
# Click the "OK" button.

[heading Beyond Quicksort]
Most of the time, however, the /speed/ of a sorting routine is more important
than the relative order of equivalent elements.  Consider the task of sorting
points by increasing distance to a target position, e.g. for raytracing or
tactical analysis.  This task must be executed efficiently if the application
runs it several times a frame at 60 frames per second.
*/
struct Point3D
{
    long x;
    long y;
    long z;
};

void displayPoint(Point3D const& p)
{
    std::cout << "[x=" << p.x << ",y=" << p.y << ",z=" << p.z << ']';
}
/*`
Since the distance comparator needs to keep track of the target position,
object-oriented principles dictate that we write the comparator as a
[link stl_primer.functors_example functor].
*/
class ByDistance
{
    Point3D const& target_position;
    bool const flag;

 public:
    ByDistance(Point3D const& player_position, bool closest_first)
        : target_position(player_position), flag(closest_first)
    {
    }

    bool operator()(Point3D const& lhs, Point3D const& rhs) const
    {
        long dx1 = lhs.x - target_position.x;
        long dy1 = lhs.y - target_position.y;
        long dz1 = lhs.z - target_position.z;
        long dx2 = rhs.x - target_position.x;
        long dy2 = rhs.y - target_position.y;
        long dz2 = rhs.z - target_position.z;

        // Since we're only comparing relative distances,
        // we don't need to perform a square root operation here.
        long lhs_dist_sq = dx1 * dx1 + dy1 * dy1 + dz1 * dz1;
        long rhs_dist_sq = dx2 * dx2 + dy2 * dy2 + dz2 * dz2;

        return
            flag
          ? (lhs_dist_sq < rhs_dist_sq)
          : (rhs_dist_sq < lhs_dist_sq);
    }
};
/*`
The [@http://www.sgi.com/tech/stl/sort.html STL `sort` algorithm] takes in the
same parameters that the [link stl_primer.sorting_example.merge_sort
`stable_sort` algorithm] does.  Earlier implementations used the *quicksort*
algorithm with *median-of-three partitioning* for pivot selection, defined in
[@http://www.amazon.com/Art-Computer-Programming-Sorting-Searching/dp/0201896850/ref=pd_bbs_6?ie=UTF8&s=books&qid=1195534683&sr=8-6
/The Art of Computer Programming. Volume 3: Sorting and Searching/ by Donald
E. Knuth]; while efficient in most cases, worst-case performance could still
occur if the wrong pivots were selected most of the time.  The current version
uses the *introsort* or *introspective sort* algorithm, outlined in
[@http://www3.interscience.wiley.com/cgi-bin/abstract/7328/ABSTRACT
"Introspective Sorting and Selection Algorithms" by David R. Musser]; its
worst-case performance is guaranteed to be still efficient.
*/
#include <vector>
#include <algorithm>

void
    nearToFar(
        std::vector<Point3D> const& player_positions
      , std::vector<Point3D>& hotspots
    )
{
    for (std::size_t i = 0; i < player_positions.size(); ++i)
    {
        std::cout << std::endl << "Player position " << i << " is ";
        displayPoint(player_positions[i]);
        std::sort(
            hotspots.begin()
          , hotspots.end()
          , ByDistance(player_positions[i], true)
        );
        std::cout << ", nearest to farthest is:" << std::endl;
        std::for_each(hotspots.begin(), hotspots.end(), displayPoint);
        std::cout << std::endl;
    }
}
/*`
[heading Sorting A List]
Both the `sort` and `stable_sort` algorithms require the input iterators to
possess [@http://www.sgi.com/tech/stl/RandomAccessIterator.html random access]
abilities.  The [link stl_primer.list_example STL `list`] does not provide
such iterators, but it does provide two `sort` method overloads.  Whichever
one you choose depends on how you want to compare the elements.
*/
#include <vector>
#include <list>
#include <algorithm>

void
    nearToFar(
        std::vector<Point3D> const& player_positions
      , std::list<Point3D>& hotspots
    )
{
    for (std::size_t i = 0; i < player_positions.size(); ++i)
    {
        std::cout << std::endl << "Player position " << i << " is ";
        displayPoint(player_positions[i]);
        hotspots.sort(ByDistance(player_positions[i], true));
        std::cout << ", nearest to farthest is:" << std::endl;
        std::for_each(hotspots.begin(), hotspots.end(), displayPoint);
        std::cout << std::endl;
    }
}
/*`
[heading Basic Heapsort]
Both *quicksort* and *introsort* are *divide-and-conquer algorithms*: each
level of recursion divides the problem space (i.e. the elements) in two, until
the problem space is small enough for a non-recursive algorithm to take over
the work.  The difference is that while quicksort uses *insertion sort* as the
recursion-terminating algorithm, introsort uses *heapsort*.  The insertion
sort algorithm runs in quadratic time--denoted as `O(N ^ 2)`--with respect to
the number of elements; heapsort, on the other hand, runs in
linear-logarithmic time--denoted as `O(N log N)`--which is faster both in
theory and in practice.

A traditional heapsort implementation would transfer the container elements to
a priority queue, then transfer them back to the original container.  The
[@http://www.sgi.com/tech/stl/priority_queue.html STL `priority_queue`] is a
[link stl_primer.adaptors_example.container_adaptors container adaptor]: it
wraps a simpler, more specific interface around an actual
[@http://www.sgi.com/tech/stl/RandomAccessContainer.html random access
container]--in our case, the [link stl_primer.deque_example STL `deque`].
*/
#include <list>
#include <deque>
#include <queue>  // std::priority_queue

void
    nearToFar(
        std::list<Point3D> const& player_positions
      , std::list<Point3D>& hotspots
    )
{
    for (
        std::list<Point3D>::const_iterator itr = player_positions.begin();
        itr != player_positions.end();
        ++itr
    )
    {
        std::cout << std::endl << "Nearest to farthest from player position ";
        displayPoint(*itr);
        std::cout << " is:" << std::endl;

        // By default, the `priority_queue` will store the element with the
        // *highest* value according to the comparator on top.  We must
        // reverse our comparator so that the `point_queue` will store the
        // element with the *lowest* value on top instead.
        std::priority_queue<Point3D,std::deque<Point3D>,ByDistance>
            point_queue(ByDistance(*itr, false));

        // Heapsort.
        while (!hotspots.empty())
        {
            point_queue.push(hotspots.back());
            hotspots.pop_back();
        }

        while (!point_queue.empty())
        {
            // Unlike a regular `queue`, which possesses a `front` method, the
            // `priority_queue` interface is similar to that of the `stack`.
            hotspots.push_back(point_queue.top());
            displayPoint(point_queue.top());
            point_queue.pop();
        }

        std::cout << std::endl;
    }
}
/*`
[heading More Control Over Heaps]
It's ironic that the very restriction that defines the `priority_queue` as an
adaptor--no iterating over its elements--leaves it next to unusable in the
application domain for which priority queues were originally designed: process
scheduling.  The reason is that the priority of a process could change as the
process is executed or spends time waiting, so the queue needs to be updated
accordingly.  It turns out that the
[link stl_primer.sorting_example.basic_heapsort STL `priority_queue`] is not
just a wrapper around the underlying container, but it is also a wrapper for
some of the heap operations we will take a look at.  The terms *heap* and
*priority queue* are synonymous.

In our scheduling example, there are two things you can do with a program
counter: get its time stamp, and increment it.  We will assume that we have a
uniprocessor system, where only the thread with the highest priority will be
executed at any time, so there's no need for more than one program counter.
*/
class ProgramCounter
{
    unsigned int current_time_stamp;

    ProgramCounter() : current_time_stamp(0)
    {
    }

    ProgramCounter(ProgramCounter const& copy)
        : current_time_stamp(copy.current_time_stamp)
    {
    }

    ~ProgramCounter()
    {
    }

 public:
    static ProgramCounter& getInstance()
    {
        static ProgramCounter instance;
        return instance;
    }

    unsigned int getCurrentTimeStamp() const
    {
        return current_time_stamp;
    }

    void update()
    {
        ++current_time_stamp;
    }
};
/*`
Our example threads will spawn new threads upon execution if they have enough
execution time remaining.  The execution time of the new threads will be cut
in half to keep the number of threads from getting too high.  Each thread will
store only the data necessary to identify it and to compute its scheduling
priority.
*/
class NiceThread
{
    static unsigned int constructed_count;
    unsigned int id;
    unsigned int last_time_stamp;
    unsigned int execution_time_remaining;

 public:
    explicit NiceThread(unsigned int estimated_run_time)
        : id(++constructed_count)
        , last_time_stamp(ProgramCounter::getInstance().getCurrentTimeStamp())
        , execution_time_remaining(estimated_run_time)
    {
        std::cout << "NiceThread " << id << " created at time stamp ";
        std::cout << last_time_stamp << " with estimated run time ";
        std::cout << execution_time_remaining << '.' << std::endl;
    }

    ~NiceThread()
    {
        std::cout << "NiceThread " << id << " destroyed." << std::endl;
    }

    unsigned int getID() const
    {
        return id;
    }

    unsigned int getLastTimeStamp() const
    {
        return last_time_stamp;
    }

    unsigned int getExecutionTimeRemaining() const
    {
        return execution_time_remaining;
    }

    // In a real operating system, new threads would be spawned by `fork`
    // instructions or the like being executed by the current thread, not as
    // values returned from a thread yielding or finishing execution.
    NiceThread* execute()
    {
        last_time_stamp = ProgramCounter::getInstance().getCurrentTimeStamp();
        std::cout << "NiceThread " << id << " executed at time stamp ";
        std::cout << last_time_stamp << " with estimated remaining time ";
        std::cout << --execution_time_remaining << '.' << std::endl;

        return
            (execution_time_remaining < 6)
          ? 0
          : new NiceThread(execution_time_remaining >> 1);
    }
};

unsigned int NiceThread::constructed_count = 0;
/*`
The [@http://en.wikipedia.org/wiki/Scheduling_algorithm scheduling algorithm]
that we will simulate is called
[@http://en.wikipedia.org/wiki/Highest_response_ratio_next *highest response
ratio next*]; the idea is that threads that have been waiting a long time
should still have opportunities to execute and not be starved of processor
time.  Because ratios involve division, our thread comparator must also be
able to handle a couple of special cases.
*/
double computePriority(NiceThread const* thread)
{
    return
        double(
            ProgramCounter::getInstance().getCurrentTimeStamp()
          - thread->getLastTimeStamp()
        )
      / thread->getExecutionTimeRemaining() + 1.0;
}

bool highestResponseRatioNext(NiceThread const* lhs, NiceThread const* rhs)
{
    if (lhs->getExecutionTimeRemaining())
    {
        if (rhs->getExecutionTimeRemaining())
        {
            return computePriority(lhs) < computePriority(rhs);
        }
        else
        {
            // Every other number is less than infinity.
            return true;
        }
    }
    else
    {
        // Infinity is not less than any other number.
        return false;
    }
}
/*`
The [@http://www.sgi.com/tech/stl/sort_heap.html `sort_heap` operation] does
/not/ organize elements into a heap.  Instead, it works the same way the
[link stl_primer.sorting_example.beyond_quicksort `sort`] and
[link stl_primer.sorting_example.merge_sort `stable_sort`] algorithms do,
except that `sort_heap` expects the elements within the input iterator range
to be already organized as a heap.
*/
#include <deque>
#include <vector>
#include <algorithm>

void show(std::deque<NiceThread*> const& thread_queue)
{
    typedef std::vector<NiceThread const*> Threads;

    // Range constructor.
    Threads threads(thread_queue.begin(), thread_queue.end());

    std::sort_heap(threads.begin(), threads.end(), highestResponseRatioNext);
    std::cout << "Sorted queue, highest to lowest:";

    for (
        Threads::const_reverse_iterator itr = threads.rbegin();
        itr != threads.rend();
        ++itr
    )
    {
        std::cout << " [" << (*itr)->getID() << ',';
        std::cout << computePriority(*itr) << ']';
    }

    std::cout << std::endl;
}
/*`
[tip
All [@http://www.sgi.com/tech/stl/Sequence.html STL sequences] possess the
*range constructor*, which takes in a pair of input iterators and fills the
new sequences with elements in the specified range.  The range constructor is
a convenient alternative to using the
[link stl_primer.adaptors_example.copying_without_presizing `copy` algorithm
with an `insert_iterator` or `back_insert_iterator` adaptor].
]

The [@http://www.sgi.com/tech/stl/push_heap.html `push_heap` operation] works
in conjunction with a container's `push_back` method to perform enqueuing,
while the [@http://www.sgi.com/tech/stl/pop_heap.html `pop_heap` operation]
works in conjunction with the container's `pop_back` method to perform
dequeuing.  Whenever changes in element priorities invalidate the integrity of
the heap, the [@http://www.sgi.com/tech/stl/make_heap.html `make_heap`
operation] rearranges the elements until they form a heap once again.

Here is the driver function for our thread scheduler:
*/
void run(std::deque<NiceThread*>& thread_queue)
{
    while (!thread_queue.empty())
    {
        // Equivalent to the `top` method of a `priority_queue`.
        NiceThread* current_thread = thread_queue.front();

        // As each thread is executed, its priority changes...
        NiceThread* new_thread = current_thread->execute();

        // ...so the entire heap must be updated as well.
        std::make_heap(
            thread_queue.begin()
          , thread_queue.end()
          , highestResponseRatioNext
        );

        // Check if the `execute` method spawned a new thread.
        if (new_thread)
        {
            // Equivalent to the `push` method of a `priority_queue`.
            // The order of operations is important.
            thread_queue.push_back(new_thread);
            std::push_heap(
                thread_queue.begin()
              , thread_queue.end()
              , highestResponseRatioNext
            );
        }

        // Check if the current thread is finished.
        if (!current_thread->getExecutionTimeRemaining())
        {
            // Equivalent to the `pop` method of a `priority_queue`.  The
            // order of operations is important.  Also, the front element is
            // transferred to the back after a `pop_heap` operation, which is
            // why `pop_back` is called next instead of `pop_front`.
            std::pop_heap(
                thread_queue.begin()
              , thread_queue.end()
              , highestResponseRatioNext
            );
            thread_queue.pop_back();

            // Clean up.
            delete current_thread;
        }

        // The priority of each thread depends on the current time stamp...
        ProgramCounter::getInstance().update();

        // ...so the entire heap must be updated as well.
        std::make_heap(
            thread_queue.begin()
          , thread_queue.end()
          , highestResponseRatioNext
        );

        if (1 < thread_queue.size())
        {
            show(thread_queue);
        }
    }
}
/*`
[caution
Make sure you use the same comparator for all heap operations on a single
container, at least until you empty it out, or else you may encounter
incorrect behavior.
]
*/
//]

#include <cstdlib>

int main()
{
    char const* teachers[] = {
        "Acosta, Keyvan             "
      , "Bahim, Richard             "
      , "Barnoske, Mike             "
      , "Beeton, Evan               "
      , "Blanchard, Jeremiah        "
      , "Carpenter, Jared           "
      , "Clingman, Dustin           "
      , "Fox, Joshua                "
      , "Hislop, Liam               "
      , "Johnson, Arthur            "
      , "Jones, Wendy               "
      , "Kendall, Shawn             "
      , "Maori, Ouns                "
      , "Mesdaghi, Syrus (the Virus)"
      , "Miller, Gary               "
      , "Nieves, Nelson             "
      , "Penney, Nick               "
      , "Preisz, Eric               "
      , "Rainey, Charles            "
      , "Rocco, Joe del             "
      , "Saedi, Shane               "
      , "Stoeffler, Rodney          "
      , "Tackett, Justin            "
      , "Van Dyke, Ryan             "
      , "Weiss, Michelle            "
      , "Wright, Richard            "
    };

    // Generate a random NDT score for each teacher.
    unsigned int const count = sizeof(teachers) / sizeof(char const*);
    std::size_t ndt_scores[count];

    for (unsigned int i = 0; i < count; ++i)
    {
        ndt_scores[i] = rand() & 15;
    }

    // Watch the STL `multimap` container in action.
    std::cout << "Sorting NDT scores..." << std::endl;
    sortScores(teachers, ndt_scores, count);

    // Generate a subset of teachers.
    std::vector<char const*> name_vector;
    std::vector<std::size_t> score_vector;

    for (unsigned int i = 0; i < count; ++i)
    {
        // Generate one or more NDT scores for each teacher in the subset.
        name_vector.push_back(teachers[rand() % count]);
        score_vector.push_back(rand() & 15);
    }

    // Watch the STL `set` container in action.
    std::cout << std::endl << "Sorting more NDT scores..." << std::endl;
    sortScores(name_vector, score_vector);

    // Watch the STL `stable_sort` algorithm in action.
    // The order of the results must match that of the 2nd `sortScores` call.
    std::cout << std::endl << "Sorting NDT scores again..." << std::endl;
    sortScoresAgain(name_vector, score_vector);

    // Use any three numbers of each Pythagorean quartet to generate the 3D
    // points.  Select the points that are farthest from each other as player
    // positions.
    std::vector<Point3D> player_positions(4);
    player_positions[0].x = 1;
    player_positions[0].y = 2;
    player_positions[0].z = 2;
    player_positions[1].x = 17;
    player_positions[1].y = 6;
    player_positions[1].z = 6;
    player_positions[2].x = 1;
    player_positions[2].y = 18;
    player_positions[2].z = 6;
    player_positions[3].x = 5;
    player_positions[3].y = 2;
    player_positions[3].z = 14;

    std::vector<Point3D> hotspots(10);
    hotspots[0].x = 3;
    hotspots[0].y = 2;
    hotspots[0].z = 6;
    hotspots[1].x = 7;
    hotspots[1].y = 4;
    hotspots[1].z = 4;
    hotspots[2].x = 1;
    hotspots[2].y = 8;
    hotspots[2].z = 4;
    hotspots[3].x = 9;
    hotspots[3].y = 6;
    hotspots[3].z = 2;
    hotspots[4].x = 7;
    hotspots[4].y = 6;
    hotspots[4].z = 6;
    hotspots[5].x = 3;
    hotspots[5].y = 4;
    hotspots[5].z = 12;
    hotspots[6].x = 11;
    hotspots[6].y = 2;
    hotspots[6].z = 10;
    hotspots[7].x = 9;
    hotspots[7].y = 12;
    hotspots[7].z = 8;
    hotspots[8].x = 1;
    hotspots[8].y = 12;
    hotspots[8].z = 12;
    hotspots[9].x = 15;
    hotspots[9].y = 6;
    hotspots[9].z = 10;

    // Make copies for the different sorting algorithms.
    std::list<Point3D> player_position_list(
        player_positions.begin()
      , player_positions.end()
    );
    std::list<Point3D> hotspot_list(
        hotspots.begin()
      , hotspots.end()
    );

    // Watch the `sort` algorithm, the `sort` method of the STL `list`
    // container, and the STL `priority_queue` adaptor in action.
    nearToFar(player_positions, hotspots);
    nearToFar(player_positions, hotspot_list);
    nearToFar(player_position_list, hotspot_list);
    std::cout << std::endl;

    // Watch the STL heap operations in action.
    std::deque<NiceThread*> thread_queue;
    thread_queue.push_back(new NiceThread(15));
    ProgramCounter::getInstance().update();
    run(thread_queue);
    std::cout << std::endl;

    return 0;
}

